"""Codex skill wrappers: `<codex>/skills/<ns>-<name>/{SKILL.md, command.md -> ~/.forge/commands/<name>.md}`.

Ported from the original `sync-forge-skills` generator: same summary extraction and name rules;
its refuse-customised and --prune behaviour now come from the linker's ownership checks.
"""
import json
from pathlib import Path
import re

from forge_cli import linker

TEMPLATE = Path(__file__).with_name('skill_template.md')
AUTO_COMMANDS = 'commands/auto'  # the one nested folder served: /forge:auto:<name>, $forge-auto-<name>
NAME_RE = re.compile(r'[a-z0-9]+(?:-[a-z0-9]+)*')


def summary(text, fallback):
    paragraphs = text.split('\n\n')
    found = next((p for p in paragraphs if p.strip() and not p.lstrip().startswith(('#', '---'))), fallback)
    return ' '.join(re.sub(r'[*`]', '', found).split()).replace('<', '').replace('>', '')[:600]


def skill_name(namespace, stem):
    name = f'{namespace}-{stem}'
    if not NAME_RE.fullmatch(name) or len(name) > 64:
        raise ValueError(f'Invalid skill name: {name}')
    return name


def render(namespace, stem, text):
    """`stem` is the path under commands/ without `.md`: `next`, or `auto/next` for a nested command."""
    skill = skill_name(namespace, stem.replace('/', '-'))
    command = stem.replace('/', ':')
    description = json.dumps(f'Run /{namespace}:{command}. {summary(text, stem)}')
    content = TEMPLATE.read_text()
    for key, value in (('skill', skill), ('description', description), ('stem', stem), ('command', command),
                       ('namespace', namespace)):
        content = content.replace('{{' + key + '}}', value)
    return content


def skill_dirs(resolved):
    """{installed skill suffix: farm-relative dir} for each `skills/<...>/SKILL.md`.

    A command of the same name wins: its Codex wrapper owns that path, and a link there would send the
    wrapper's writes through into the farm. `forge auto check` reports the clash.
    """
    commands = {rel[len('commands/'):-len('.md')].replace('/', '-') for rel in resolved
                if rel.startswith('commands/') and rel.endswith('.md')}
    found = {}
    for rel in resolved:
        parts = Path(rel).parts
        if parts[0] == 'skills' and parts[-1] == 'SKILL.md' and len(parts) > 2:
            suffix = '-'.join(parts[1:-1])
            if suffix not in commands:
                found[suffix] = Path(*parts[:-1]).as_posix()
    return found


def harnesses(text):
    """The `harnesses: [claude, codex]` frontmatter list; absent means every harness."""
    match = re.match(r'---\n(.*?)\n---\n', text, re.S)
    found = match and re.search(r'^harnesses:\s*\[([^\]]*)\]', match.group(1), re.M)
    return [h.strip() for h in found.group(1).split(',') if h.strip()] if found else None


def ops(paths, namespace, resolved):
    result = []
    for rel in resolved:
        if not (rel.startswith('commands/') and rel.endswith('.md')):
            continue
        if not (rel.count('/') == 1 or Path(rel).parent.as_posix() == AUTO_COMMANDS):
            continue
        stem = rel[len('commands/'):-len('.md')]
        farm_file = paths.forge_home / rel
        text = (paths.core_source if resolved[rel] == 'core' else paths.user).joinpath(rel).read_text()
        if 'codex' not in (harnesses(text) or ['codex']):
            continue
        dest = paths.codex_dir / 'skills' / skill_name(namespace, stem.replace('/', '-'))
        result += [
            linker.directory(dest),
            linker.file(dest / 'SKILL.md', render(namespace, stem, text)),
            linker.symlink(dest / 'command.md', farm_file),
        ]
    for suffix, rel in skill_dirs(resolved).items():
        result.append(linker.symlink(paths.codex_dir / 'skills' / skill_name(namespace, suffix), paths.forge_home / rel))
    return result
