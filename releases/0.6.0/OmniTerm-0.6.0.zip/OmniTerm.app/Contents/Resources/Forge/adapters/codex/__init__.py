"""Codex CLI: generated skill wrappers plus agent TOMLs generated from the markdown agents.

Agent TOMLs always land in ~/.forge/build/codex/<namespace>/agents/; they are installed into <codex>/agents/
only for a non-preview namespace (the cutover). Under the preview, `forge doctor` reports drift.
"""
from forge_cli import linker
from forge_cli.paths import PREVIEW_NAMESPACE

from . import agents_toml, wrappers


def agent_sources(paths, resolved):
    return [(paths.core_source if layer == 'core' else paths.user) / rel
            for rel, layer in resolved.items()
            if rel.startswith('agents/') and rel.endswith('.md')]


def ops(paths, namespace, resolved):
    result = wrappers.ops(paths, namespace, resolved)
    built = agents_toml.build(agent_sources(paths, resolved))
    build_dir = paths.build / 'codex' / namespace / 'agents'
    for name, toml in built.items():
        result.append(linker.file(build_dir / name, toml))
        if namespace != PREVIEW_NAMESPACE:
            result.append(linker.file(paths.codex_dir / 'agents' / name, toml))
    return result


def drift(paths, resolved):
    return agents_toml.drift(agents_toml.build(agent_sources(paths, resolved)), paths.codex_dir / 'agents')
