"""Harness adapters. Each exposes `ops(paths, namespace, resolved) -> list[linker.Op]`."""
from . import claude, codex

REGISTRY = {'claude': claude, 'codex': codex}
