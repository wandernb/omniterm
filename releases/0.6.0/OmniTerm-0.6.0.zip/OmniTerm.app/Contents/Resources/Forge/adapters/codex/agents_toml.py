"""Codex agent TOMLs generated from the markdown agents, so they can no longer drift from source."""
import json
from pathlib import Path
import tomllib


def parse_markdown(text):
    """Split `---` frontmatter (flat `key: value` lines) from the body."""
    if not text.startswith('---\n'):
        raise ValueError('agent file has no frontmatter')
    head, _, body = text[4:].partition('\n---\n')
    meta = {}
    for line in head.splitlines():
        key, sep, value = line.partition(':')
        if sep:
            meta[key.strip()] = value.strip()
    return meta, body.strip('\n')


def _basic(value):
    # JSON string escaping is valid TOML basic-string escaping for these characters.
    return json.dumps(value, ensure_ascii=False)


def _multiline(value):
    if "'''" not in value:
        return f"'''\n{value}'''"
    escaped = value.replace('\\', '\\\\').replace('"""', '""\\"')
    return f'"""\n{escaped}"""'


def render(text):
    meta, body = parse_markdown(text)
    for key in ('name', 'description'):
        if not meta.get(key):
            raise ValueError(f'agent frontmatter lacks {key}')
    toml = (f'name = {_basic(meta["name"])}\n'
            f'description = {_basic(meta["description"])}\n'
            f'developer_instructions = {_multiline(body)}\n')
    parsed = tomllib.loads(toml)
    if parsed['developer_instructions'] != body or parsed['description'] != meta['description']:
        raise ValueError(f'TOML round-trip mismatch for {meta["name"]}')
    return toml


def build(agent_files):
    """{'forge-scout.toml': '<toml>', ...} from agent markdown paths."""
    return {Path(p).stem + '.toml': render(Path(p).read_text()) for p in sorted(agent_files)}


def drift(generated, installed_dir):
    """Names whose installed TOML differs semantically from the generated one (or is missing)."""
    report = {}
    for name, toml in sorted(generated.items()):
        installed = Path(installed_dir) / name
        if not installed.is_file():
            report[name] = 'missing'
            continue
        want = tomllib.loads(toml)
        try:
            have = tomllib.loads(installed.read_text())
        except tomllib.TOMLDecodeError as error:
            report[name] = f'unparseable ({error})'
            continue
        changed = sorted(k for k in set(want) | set(have) if want.get(k) != have.get(k))
        if changed:
            report[name] = 'differs: ' + ', '.join(changed)
    return report
