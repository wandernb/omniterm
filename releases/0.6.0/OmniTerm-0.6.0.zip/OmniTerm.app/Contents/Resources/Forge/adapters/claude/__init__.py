"""Claude Code: plain symlinks, so command names stay `/<namespace>:<name>` and agents keep theirs.

The preview namespace only links the commands directory: agents are matched by their `name:`
frontmatter, so linking a second copy beside the live `~/.claude/agents/forge-*.md` would shadow
them. A non-preview namespace (the cutover) also links agents per file and keeps the old
`~/.claude/knowledge/forge*` paths alive as links into the farm, for projects that cite them.
"""
from adapters.codex.wrappers import skill_dirs, skill_name
from forge_cli import linker
from forge_cli.paths import PREVIEW_NAMESPACE


def ops(paths, namespace, resolved):
    result = [linker.symlink(paths.claude_dir / 'commands' / namespace, paths.forge_home / 'commands')]
    if namespace == PREVIEW_NAMESPACE:
        return result
    for rel in resolved:
        top = rel.count('/') == 1
        if rel.startswith('agents/') and rel.endswith('.md') and top:
            result.append(linker.symlink(paths.claude_dir / rel, paths.forge_home / rel))
        elif rel.startswith('knowledge/forge-') and rel.endswith('.md') and top:
            result.append(linker.symlink(paths.claude_dir / rel, paths.forge_home / rel))
    for suffix, rel in skill_dirs(resolved).items():
        result.append(linker.symlink(paths.claude_dir / 'skills' / skill_name(namespace, suffix), paths.forge_home / rel))
    if any(rel.startswith('knowledge/forge/') for rel in resolved):
        result.append(linker.symlink(paths.claude_dir / 'knowledge/forge', paths.forge_home / 'knowledge/forge'))
    return result
