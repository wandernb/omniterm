---
name: {{skill}}
description: {{description}}
---

# Forge {{command}}

Read [the live command](command.md) completely before following its workflow.
It links to `~/.forge/commands/{{stem}}.md`, resolved by `forge link` from the core or user layer; that file is the source of truth.

## Codex adaptation

- Treat the text after `${{skill}}` (or `/{{namespace}}:{{command}}`) as `$ARGUMENTS`; preserve flags and apply the source's defaults when absent.
- Resolve relative links in the command against `~/.forge/commands/`, not this wrapper. Read referenced knowledge (`~/.forge/knowledge/`) and agent instructions (`~/.forge/agents/`) when required.
- For nested `/forge:NAME` calls, load `${{namespace}}-NAME` or `~/.forge/commands/NAME.md` and follow it with the specified arguments. These are workflows, not shell commands.
- Map Claude Read/Grep/Glob/Edit/Write/Bash operations to available Codex file, search, patch and execution tools. Map Task delegation to available Codex agents; use the named role when available, otherwise load its definition from `~/.forge/agents/` and pass it to an available agent. Respect current delegation constraints and report a missing capability instead of pretending it ran.
- Preserve the command's scope, approval boundaries, verification and reporting requirements. Current user instructions and project AGENTS.md take precedence; protect concurrent work.
- Claude-only native commands, session stores, hooks and plugin integrations are not automatically provided by this bridge. Use a verified Codex equivalent if available; otherwise explain the unsupported step. Never silently redirect Claude session operations to Codex sessions or substitute this same conversation for a required independent review.
