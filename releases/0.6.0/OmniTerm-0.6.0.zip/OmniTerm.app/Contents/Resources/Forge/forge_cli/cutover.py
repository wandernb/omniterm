"""Cutover: back up, take over the live `forge` namespace, roll back, clean up.

Every destructive step is preceded by a tarball of exactly what it touches, kept under
~/.forge/state/backups/<label>-<stamp>/ with a manifest, so `forge rollback` can put it back.
"""
from datetime import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

from . import linker, state as state_mod

NAMESPACE = 'forge'
PREVIEW = 'forgex'
GROUPS = (f'claude:{NAMESPACE}', f'codex:{NAMESPACE}')

# Paths the takeover replaces with forge-owned links (relative to the claude / codex roots).
CLAUDE_TAKEOVER = ('commands/forge', 'agents/forge-*.md', 'knowledge/forge-*.md', 'knowledge/forge')
CODEX_TAKEOVER = ('skills/forge-*', 'agents/forge-*.toml')
# Global config files the install edits; backed up, restored only with `rollback --config`.
CONFIG = (('claude', 'AGENTS.md'), ('claude', 'settings.json'), ('codex', 'hooks.json'))
# Retired by `forge cleanup` once the takeover is verified.
CLAUDE_RETIRE = ('skills/source-command-forge-*',)
CODEX_RETIRE = ('skills/sync-forge-skills',)

GITIGNORE_BEGIN = '# forge:begin (managed by `forge cleanup`; served from ~/.forge)'
GITIGNORE_END = '# forge:end'
GITIGNORE_LINES = ('/commands/forge', '/commands/forgex', '/agents/forge-*.md', '/knowledge/forge-*.md', '/knowledge/forge')


def _exists(path):
    return path.exists() or path.is_symlink()


def _glob(root, patterns):
    found = []
    for pattern in patterns:
        found += [p for p in sorted(root.glob(pattern)) if _exists(p)]
        direct = root / pattern
        if '*' not in pattern and direct.is_symlink() and direct not in found:
            found.append(direct)  # dangling links are invisible to glob
    return found


def takeover_paths(paths):
    return _glob(paths.claude_dir, CLAUDE_TAKEOVER) + _glob(paths.codex_dir, CODEX_TAKEOVER)


def retire_paths(paths):
    return _glob(paths.claude_dir, CLAUDE_RETIRE) + _glob(paths.codex_dir, CODEX_RETIRE)


def config_paths(paths):
    roots = {'claude': paths.claude_dir, 'codex': paths.codex_dir}
    return [roots[root] / name for root, name in CONFIG]


def _within(path, paths):
    return any(root == path or root in path.parents for root in (paths.claude_dir, paths.codex_dir))


# ---------------------------------------------------------------- backup / restore

def backup(paths, label, entries, preview=False):
    """Tar {path: kind} (kind: takeover | config | retire) into a new backup dir; return its path.
    `preview` records whether the forgex preview was linked, so rollback can relink it."""
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    target = paths.state_dir / 'backups' / f'{label}-{stamp}'
    target.mkdir(parents=True)
    manifest = {'label': label, 'created': stamp, 'preview': preview, 'entries': []}
    with tarfile.open(target / 'archive.tar.gz', 'w:gz') as archive:
        for path, kind in entries.items():
            existed = _exists(path)
            if existed:
                archive.add(str(path), arcname=str(path).lstrip('/'), recursive=True)
            manifest['entries'].append({'path': str(path), 'kind': kind, 'existed': existed})
    (target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return target


def backups(paths, label=None):
    root = paths.state_dir / 'backups'
    if not root.is_dir():
        return []
    found = [d for d in sorted(root.iterdir()) if (d / 'manifest.json').is_file()]
    return [d for d in found if label is None or d.name.startswith(f'{label}-')]


def _remove(path):
    if path.is_symlink() or path.is_file():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)


def restore(paths, backup_dir, kinds):
    """Put every manifest entry of the given kinds back exactly as it was at backup time."""
    manifest = json.loads((backup_dir / 'manifest.json').read_text())
    report = []
    with tarfile.open(backup_dir / 'archive.tar.gz', 'r:gz') as archive:
        members = archive.getmembers()
        for entry in manifest['entries']:
            if entry['kind'] not in kinds:
                continue
            path = Path(entry['path'])
            if not _within(path, paths):
                raise ValueError(f'refusing to restore outside the harness roots: {path}')
            if _exists(path):
                _remove(path)
            if entry['existed']:
                arc = entry['path'].lstrip('/')
                chosen = [m for m in members if m.name == arc or m.name.startswith(arc + '/')]
                archive.extractall('/', members=chosen, filter='fully_trusted')
                report.append(f'restored: {path}')
            else:
                report.append(f'removed (absent at backup time): {path}')
    return report


# ---------------------------------------------------------------- takeover / rollback

def plan_takeover(paths, ops):
    """Paths the takeover must clear: every live forge path plus anything an op would collide with."""
    targets = set(takeover_paths(paths))
    current = state_mod.load(paths.state_file)
    for op in ops:
        if _exists(op.path) and str(op.path) not in current['entries']:
            if not any(op.path == t or t in op.path.parents for t in targets):
                raise ValueError(f'takeover would collide with a non-forge path: {op.path}')
    return sorted(targets)


def takeover(paths, link, adapters_ops, harnesses, dry_run=False, preview=None):
    """Back up and clear the live forge paths, link namespace `forge` from ~/.forge, then drop the
    preview: Claude Code loads one commands dir per real path, so a `forgex` link to the same
    ~/.forge/commands would hide `/forge:*`. `preview` = (unlink, relink) callables."""
    targets = plan_takeover(paths, adapters_ops)
    if dry_run:
        report = [f'would back up: {c}' for c in config_paths(paths) if _exists(c)]
        report += [f'would back up + clear: {t}' for t in targets]
        return report + [f'would {op.kind}: {op.path}' for op in adapters_ops]
    entries = {t: 'takeover' for t in targets}
    entries.update({c: 'config' for c in config_paths(paths)})
    preview_linked = PREVIEW in state_mod.load(paths.state_file)['namespaces']
    saved = backup(paths, 'takeover', entries, preview=preview_linked)
    for target in targets:
        _remove(target)
    report = [f'backup: {saved}'] + [f'cleared: {t}' for t in targets]
    try:
        report += link(paths, [NAMESPACE], harnesses, quiet=True)
        if preview_linked and preview:
            report += preview[0]()
    except Exception:
        report += rollback(paths, saved, relink=preview[1] if preview else None)
        raise
    return report


def rollback(paths, backup_dir=None, config=False, relink=None):
    """Undo a takeover (drop namespace `forge`, restore the live paths) or, given a cleanup
    backup, undo the cleanup (restore the retired files and .gitignore, relink the preview)."""
    candidates = backups(paths, 'takeover')
    backup_dir = Path(backup_dir) if backup_dir else (candidates[-1] if candidates else None)
    if backup_dir is None:
        raise ValueError('no takeover backup found under ~/.forge/state/backups')
    manifest = json.loads((backup_dir / 'manifest.json').read_text())
    label = manifest['label']
    if label == 'cleanup':
        report = restore(paths, backup_dir, {'retire', 'config'})
        if manifest.get('preview') and relink:
            report += relink()
        return report + [f'cleanup rolled back from {backup_dir}']
    with state_mod.locked(paths.state_dir):
        current = state_mod.load(paths.state_file)
        report = linker.uninstall(set(GROUPS), current)
        current['namespaces'].pop(NAMESPACE, None)
        state_mod.save(paths.state_file, current)
    kinds = {'takeover', 'config'} if config else {'takeover'}
    report += restore(paths, backup_dir, kinds)
    if manifest.get('preview') and relink:
        report += relink()
    return report + [f'rolled back from {backup_dir}']


# ---------------------------------------------------------------- cleanup

def render_gitignore(text):
    block = '\n'.join((GITIGNORE_BEGIN,) + GITIGNORE_LINES + (GITIGNORE_END,)) + '\n'
    start = text.find(GITIGNORE_BEGIN)
    if start == -1:
        return text + ('' if text.endswith('\n\n') or not text else '\n' if text.endswith('\n') else '\n\n') + block
    end = text.index(GITIGNORE_END, start) + len(GITIGNORE_END)
    return text[:start] + block.rstrip('\n') + text[end:]


def tracked_forge_paths(paths):
    """Paths git still tracks in the claude repo that are now forge links (for the user's commit)."""
    if not (paths.claude_dir / '.git').exists():
        return []
    patterns = [p.lstrip('/') for p in GITIGNORE_LINES]
    result = subprocess.run(['git', '-C', str(paths.claude_dir), 'ls-files', '--', *patterns],
                            capture_output=True, text=True)
    return [line for line in result.stdout.splitlines() if line]


def git_rm_specs(tracked):
    """Collapse tracked files under the two forge directories into one pathspec each."""
    specs = set()
    for path in tracked:
        parts = path.split('/')
        specs.add('/'.join(parts[:2]) if parts[:2] in (['commands', 'forge'], ['knowledge', 'forge']) else path)
    return sorted(specs)


def cleanup(paths, uninstall_preview, dry_run=True):
    """After a verified takeover: drop the preview, retire the old generators, update .gitignore."""
    current = state_mod.load(paths.state_file)
    if NAMESPACE not in current['namespaces']:
        raise ValueError('cleanup runs after the takeover; namespace `forge` is not linked yet')
    preview_linked = PREVIEW in current['namespaces']
    retired = retire_paths(paths)
    gitignore = paths.claude_dir / '.gitignore'
    before = gitignore.read_text() if gitignore.exists() else ''
    after = render_gitignore(before)
    report = [f'{"would retire" if dry_run else "retired"}: {p}' for p in retired]
    report.append(f'{"would update" if dry_run else "updated"}: {gitignore}' if before != after else f'unchanged: {gitignore}')
    if dry_run:
        if preview_linked:
            report.insert(0, 'would uninstall namespace forgex (claude + codex)')
        return report
    entries = {p: 'retire' for p in retired}
    entries[gitignore] = 'config'
    saved = backup(paths, 'cleanup', entries, preview=preview_linked)
    report.insert(0, f'backup: {saved}')
    if preview_linked:
        report += uninstall_preview()
    for path in retired:
        _remove(path)
    if before != after:
        tmp = gitignore.with_name('.gitignore.forge-tmp')
        tmp.write_text(after)
        os.replace(tmp, gitignore)
    return report
