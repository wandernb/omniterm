"""install.json: every path forge owns, so doctor can check it and uninstall can remove exactly it."""
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os

VERSION = 1


def sha256(data):
    if isinstance(data, str):
        data = data.encode()
    return hashlib.sha256(data).hexdigest()


def empty():
    return {'version': VERSION, 'namespaces': {}, 'entries': {}, 'managed': {}}


def load(path):
    if not path.exists():
        return empty()
    state = json.loads(path.read_text())
    if state.get('version') != VERSION:
        raise ValueError(f'Unsupported state version in {path}: {state.get("version")}')
    state.setdefault('namespaces', {})
    state.setdefault('entries', {})
    state.setdefault('managed', {})
    return state


def save(path, state):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'.{path.name}.tmp')
    tmp.write_text(json.dumps(state, indent=2, sort_keys=True) + '\n')
    os.replace(tmp, path)


@contextmanager
def locked(state_dir, enabled=True):
    """Serialise LaunchAgent repairs against manual `forge link` runs."""
    if not enabled:
        yield
        return
    state_dir.mkdir(parents=True, exist_ok=True)
    with open(state_dir / 'lock', 'w') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)
