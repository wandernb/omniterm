"""Retire and restore forge commands: `<layer>/.attic/` keeps them, and nothing there is ever served.

Deterministic guards, so an unattended run cannot talk itself past them. A core command is only ever
retired inside a worktree (`--core-root`), because the live `core/` serves every session; a name that
another file still cites is refused, because that reference would dangle.
"""
from datetime import date
from pathlib import Path
import re
import shutil

from . import layers

# The suite that does the tending, and the meta-commands it relies on.
KEPT = frozenset({'forge', 'reforge', 'maintain', 'distill', 'retire', 'sharpen', 'dream', 'vision', 'advance'})
INDEX = 'INDEX.md'
CATALOG_NAME = 'forge-auto-catalog.md'  # generated from the commands; rewritten after every retirement
HEADER = '# Attic\n\nRetired forge files. `forge attic restore <name>` brings one back.\n\n| Date | Name | Why |\n|---|---|---|\n'


def _candidates(name):
    """Paths a name may occupy in a layer: its command file and, for generated names, its skill dir."""
    if name.startswith('auto:'):
        stem = name[len('auto:'):]
        return [Path('commands/auto') / f'{stem}.md', Path('skills/auto') / stem]
    return [Path('commands') / f'{name}.md', Path('extensions') / f'{name}.md']


def _validate(name):
    if not re.fullmatch(r'(auto:)?[a-z0-9]+(-[a-z0-9]+)*', name):
        raise ValueError(f'invalid command name: {name}')


def _citations(root, name):
    """Files under a layer root still citing the name, the file being retired excluded."""
    pattern = re.compile(rf'(?<![\w/-])(?:/forge:{re.escape(name)}|\$forge-{re.escape(name.replace(":", "-"))})(?![\w-])')
    own = {str(path) for path in _candidates(name)}
    found = []
    for kind in layers.KINDS:
        base = root / kind
        for path in sorted(base.rglob('*.md')) if base.is_dir() else ():
            rel = path.relative_to(root)
            if str(rel) in own or rel.name == CATALOG_NAME or (kind == 'knowledge' and len(rel.parts) > 2):
                continue
            if pattern.search(path.read_text(errors='replace')):
                found.append(rel.as_posix())
    return found


def _locate(paths, name, core_root):
    """(layer root, existing relative paths). A name in both layers is ambiguous and is refused."""
    core = Path(core_root) if core_root else paths.core_source
    in_user = [rel for rel in _candidates(name) if (paths.user / rel).exists()]
    in_core = [rel for rel in _candidates(name) if (core / rel).exists()]
    if in_user and in_core:
        raise ValueError(f'{name} exists in both layers; remove the user shadow by hand first')
    if in_user:
        return paths.user, in_user
    if in_core:
        return core, in_core
    raise ValueError(f'no such command: {name}')


def _record(root, name, why, dry_run):
    index = root / '.attic' / INDEX
    if not dry_run:
        index.parent.mkdir(parents=True, exist_ok=True)
        if not index.exists():
            index.write_text(HEADER)
        with open(index, 'a') as handle:
            handle.write(f'| {date.today().isoformat()} | {name} | {" ".join(why.split()).replace("|", "/")} |\n')


def add(paths, name, why, core_root=None, dry_run=False):
    """Move a command into its layer's attic. Returns (report lines, whether the farm needs relinking)."""
    _validate(name)
    if name in KEPT:
        raise ValueError(f'{name} is part of the self-tending suite and is never retired')
    if not why.strip():
        raise ValueError('--why is required: the attic is only useful if it says why')
    root, found = _locate(paths, name, core_root)
    if root != paths.user and not core_root:
        raise ValueError(f'{name} lives in core: retire it in a worktree with --core-root <worktree>/core')
    cited = _citations(root, name)
    if cited:
        raise ValueError(f'{name} is still cited by: {", ".join(cited)}')
    report = []
    for rel in found:
        target = root / '.attic' / rel
        if target.exists():
            raise ValueError(f'already in the attic: {target}')
        report.append(f'{"would retire" if dry_run else "retired"}: {root / rel} -> {target}')
        if not dry_run:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(root / rel), str(target))
    _record(root, name, why, dry_run)
    return report, root == paths.user and not dry_run


def restore(paths, name, core_root=None, dry_run=False):
    _validate(name)
    core = Path(core_root) if core_root else paths.core_source
    for root in (paths.user, core):
        found = [rel for rel in _candidates(name) if (root / '.attic' / rel).exists()]
        if not found:
            continue
        if root != paths.user and not core_root:
            raise ValueError(f'{name} was retired from core: restore it in a worktree with --core-root <worktree>/core')
        report = []
        for rel in found:
            if (root / rel).exists():
                raise ValueError(f'refusing to overwrite {root / rel}')
            report.append(f'{"would restore" if dry_run else "restored"}: {root / rel}')
            if not dry_run:
                (root / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(root / '.attic' / rel), str(root / rel))
        return report, root == paths.user and not dry_run
    raise ValueError(f'not in the attic: {name}')


def listing(paths, core_root=None):
    lines = []
    for root in (paths.user, Path(core_root) if core_root else paths.core_source):
        index = root / '.attic' / INDEX
        if index.is_file():
            lines += [line for line in index.read_text().splitlines()
                      if line.startswith('| 2')]
    return lines or ['the attic is empty']
