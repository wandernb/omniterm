"""Forge's harness hooks, merged into Claude settings.json / Codex hooks.json.

- **SessionStart** `forge session-start`: prints the session brief (plus a health line when something is
  wrong); both harnesses add that stdout to the context. The matcher re-runs it after compaction.
- **Stop** `forge storage stop-hook`: once per session, when the session is about to end with storage
  leftovers of its own (expired ledger rows, unledgered heavy files), asks it to tidy them silently.

Both harnesses use the same `{"hooks": {"<Event>": [{"hooks": [{"type": "command", ...}]}]}}` shape.
The merge is JSON-aware, idempotent, preserves every other key, and backs the file up before writing.
"""
import json
import shlex

from . import backups

MARKER = 'session-start'
LEGACY_MARKERS = ('doctor --hook',)
MATCHER = 'startup|resume|clear|compact'

# event -> (subcommand, markers that identify our hook, matcher or None)
EVENTS = {
    'SessionStart': (MARKER, (MARKER,) + LEGACY_MARKERS, MATCHER),
    'Stop': ('storage stop-hook', ('storage stop-hook',), None),
}


def target(paths, harness):
    return {'claude': paths.claude_dir / 'settings.json', 'codex': paths.codex_dir / 'hooks.json'}[harness]


def command(paths, event='SessionStart'):
    forge = shlex.quote(str(paths.repo / 'bin' / 'forge'))
    return f'[ -x {forge} ] && {forge} {EVENTS[event][0]} || true'


def _ours(hook, event):
    text = hook.get('command', '')
    return (hook.get('type') == 'command' and 'bin/forge' in text
            and any(marker in text for marker in EVENTS[event][1]))


def merge(settings, hook_command, event='SessionStart'):
    """Return (settings, changed) with exactly one forge `event` hook carrying hook_command."""
    settings = json.loads(json.dumps(settings))
    matcher = EVENTS[event][2]
    groups = settings.setdefault('hooks', {}).setdefault(event, [])
    for group in groups:
        for hook in group.get('hooks', []):
            if _ours(hook, event):
                if hook['command'] == hook_command and group.get('matcher') == matcher:
                    return settings, False
                hook['command'] = hook_command
                if matcher is None:
                    group.pop('matcher', None)
                else:
                    group['matcher'] = matcher
                return settings, True
    group = {'hooks': [{'type': 'command', 'command': hook_command}]}
    if matcher is not None:
        group = {'matcher': matcher, **group}
    groups.append(group)
    return settings, True


def remove(settings, event='SessionStart'):
    """Drop our hook from `event`; drop only the groups that our removal emptied."""
    settings = json.loads(json.dumps(settings))
    groups = settings.get('hooks', {}).get(event, [])
    changed, kept_groups = False, []
    for group in groups:
        hooks = group.get('hooks', [])
        kept = [h for h in hooks if not _ours(h, event)]
        if len(kept) != len(hooks):
            changed = True
            if not kept:
                continue
            group['hooks'] = kept
        kept_groups.append(group)
    if changed:
        settings['hooks'][event] = kept_groups
        if not kept_groups:
            del settings['hooks'][event]
    return settings, changed


def merge_all(settings, paths):
    changed = False
    for event in EVENTS:
        settings, event_changed = merge(settings, command(paths, event), event)
        changed |= event_changed
    return settings, changed


def remove_all(settings):
    changed = False
    for event in EVENTS:
        settings, event_changed = remove(settings, event)
        changed |= event_changed
    return settings, changed


def _write(path, settings, backup_dir):
    if path.exists():
        backups.keep(path, backup_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'.{path.name}.forge-tmp')
    tmp.write_text(json.dumps(settings, indent=2, ensure_ascii=False) + '\n')
    tmp.replace(path)


def install(paths, harness, dry_run=False):
    path = target(paths, harness)
    current = json.loads(path.read_text()) if path.exists() else {}
    updated, changed = merge_all(current, paths)
    if changed and not dry_run:
        _write(path, updated, paths.state_dir / 'backups')
    return path, changed


def uninstall(paths, harness, dry_run=False):
    path = target(paths, harness)
    if not path.exists():
        return path, False
    updated, changed = remove_all(json.loads(path.read_text()))
    if changed and not dry_run:
        _write(path, updated, paths.state_dir / 'backups')
    return path, changed
