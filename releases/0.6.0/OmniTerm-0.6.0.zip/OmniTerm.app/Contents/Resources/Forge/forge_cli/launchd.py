"""The keep-alive LaunchAgent: relink when a layer changes, repair every 15 minutes.

WatchPaths fires when a watched directory's entries change (add/remove/rename), so each kind
directory of core and user is watched, not just the layer roots.
"""
import getpass
import os
import plistlib
import subprocess
import sys

from . import linker
from .layers import KINDS

GROUP = 'launchd'
REPAIR_INTERVAL = 900


def label():
    return f'com.{getpass.getuser()}.forge'


def plist_path(paths):
    return paths.launch_agents / f'{label()}.plist'


def watch_paths(paths):
    """Every kind dir of both layers, existing or not, plus the layer roots (which change when a
    kind dir is created), so the definition never goes stale as the user layer grows."""
    roots = [paths.core_source, paths.user]
    return [str(root) for root in roots] + [str(root / kind) for root in roots for kind in KINDS]


def render(paths, python=None):
    logs = paths.logs
    data = {
        'Label': label(),
        'ProgramArguments': [python or sys.executable, str(paths.repo / 'bin' / 'forge'), 'doctor', '--repair', '--hook'],
        'EnvironmentVariables': {'HOME': str(paths.home), 'FORGE_HOME': str(paths.forge_home),
                                 'CLAUDE_CONFIG_DIR': str(paths.claude_dir), 'CODEX_HOME': str(paths.codex_dir)},
        'RunAtLoad': True,
        'WatchPaths': watch_paths(paths),
        'StartInterval': REPAIR_INTERVAL,
        'ThrottleInterval': 10,
        'ProcessType': 'Background',
        'StandardOutPath': str(logs / 'launchd.out.log'),
        'StandardErrorPath': str(logs / 'launchd.err.log'),
    }
    return plistlib.dumps(data, sort_keys=False).decode()


def _launchctl(*args):
    return subprocess.run(['launchctl', *args], capture_output=True, text=True)


def install(paths, current_state, dry_run=False, runner=_launchctl):
    report = linker.apply([linker.file(plist_path(paths), render(paths))], GROUP, current_state, dry_run)
    if dry_run:
        return report
    paths.logs.mkdir(parents=True, exist_ok=True)
    domain = f'gui/{os.getuid()}'
    runner('bootout', f'{domain}/{label()}')  # reload with the new definition; absent is fine
    result = runner('bootstrap', domain, str(plist_path(paths)))
    if result.returncode != 0:
        raise OSError(f'launchctl bootstrap failed: {result.stderr.strip()}')
    report.append(f'loaded: {label()}')
    return report


def uninstall(paths, current_state, dry_run=False, runner=_launchctl):
    if dry_run:
        return linker.uninstall({GROUP}, current_state, dry_run=True)
    runner('bootout', f'gui/{os.getuid()}/{label()}')
    return linker.uninstall({GROUP}, current_state)
