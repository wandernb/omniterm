"""Every filesystem root forge touches, overridable through the environment.

Tests (and sandboxed rehearsals) point HOME, FORGE_HOME, CLAUDE_CONFIG_DIR and CODEX_HOME at temp
dirs; nothing in forge reads Path.home() directly.
"""
from dataclasses import dataclass
import os
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

# Namespace used side by side with the live suite until the cutover (slice 6).
PREVIEW_NAMESPACE = 'forgex'


@dataclass(frozen=True)
class Paths:
    home: Path
    forge_home: Path
    claude_dir: Path
    codex_dir: Path
    repo: Path

    @classmethod
    def from_env(cls, env=None):
        env = os.environ if env is None else env
        home = Path(env.get('HOME') or Path.home())
        return cls(
            home=home,
            forge_home=Path(env.get('FORGE_HOME') or home / '.forge'),
            claude_dir=Path(env.get('CLAUDE_CONFIG_DIR') or home / '.claude'),
            codex_dir=Path(env.get('CODEX_HOME') or home / '.codex'),
            repo=Path(env.get('FORGE_REPO') or REPO_ROOT),
        )

    @property
    def core_source(self):
        return self.repo / 'core'

    @property
    def core(self):
        return self.forge_home / 'core'

    @property
    def user(self):
        return self.forge_home / 'user'

    @property
    def state_dir(self):
        return self.forge_home / 'state'

    @property
    def state_file(self):
        return self.state_dir / 'install.json'

    @property
    def logs(self):
        return self.state_dir / 'logs'

    @property
    def build(self):
        return self.forge_home / 'build'

    @property
    def launch_agents(self):
        return self.home / 'Library' / 'LaunchAgents'
