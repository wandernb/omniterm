"""Project exposure: how careful an agent must be, read from a private map (doctrine: Momentum M14).

User config (optional, private): `<forge>/user/exposure.json`

    {"projects": {"~/Projects/acme": {"tier": "internal", "guard": "box shared with acme-web"}}}

The longest whole-component path match wins. Anything unlisted, and everything when the map is missing
or unreadable, is protected: an error here must never make a project look freer than it is.
"""
import json
import os
from pathlib import Path

PROTECTED = 'protected'
TIERS = (PROTECTED, 'internal')


def _resolve(path, paths):
    text = str(path)
    if text == '~' or text.startswith('~/'):
        text = str(paths.home) + text[1:]
    return Path(os.path.realpath(text))


def load(paths):
    """Return {resolved path: (tier, guard)}, or {} when the map is missing or malformed."""
    try:
        projects = json.loads((paths.user / 'exposure.json').read_text())['projects']
        return {_resolve(path, paths): (entry['tier'], entry.get('guard', '')) for path, entry in projects.items()}
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return {}


def lookup(paths, target=None):
    """Return (tier, guard, listed) for a path, defaulting to the working directory."""
    resolved = _resolve(target or os.getcwd(), paths)
    matches = [root for root in load(paths) if root == resolved or root in resolved.parents]
    if not matches:
        return PROTECTED, '', False
    tier, guard = load(paths)[max(matches, key=lambda root: len(root.parts))]
    return (tier, guard, True) if tier in TIERS else (PROTECTED, guard, True)


def line(paths, target=None):
    """The session-brief line: label, guard, and on internal projects that shipping is routine."""
    tier, guard, listed = lookup(paths, target)
    label = tier if listed else f'{tier} (not in the map)'
    routine = ' Commits, releases and deploys are routine here.' if tier == 'internal' else ''
    return f'- **Exposure**: {label}.' + (f' Guard: {guard}' if guard else '') + routine + ' (Momentum M14)\n'
