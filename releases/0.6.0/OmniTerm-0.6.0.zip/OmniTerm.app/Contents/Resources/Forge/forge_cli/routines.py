"""Deterministic merge gate for routine PRs: no model decides a merge.

`forge routines sweep` merges a PR only when every gate holds; it never force-merges, never bypasses a
review and never touches a dirty checkout. Repos and their merge policy live in the private user layer:

    <forge>/user/routines.json
    {"repos": {"sdk": {"github": "org/sdk", "head": "~/Projects/sdk/@head", "target": "develop",
                       "merge": "review", "merge_note": "why"}}}

`merge` is "auto" or "review". Anything but an explicit "auto" holds every PR for a human.

Every branch forge creates is prefixed `forge/`. Routine work never targets `target` directly. It
gathers on one long-lived **integration branch** (`integration`, default "forge/maintenance"), which a single standing PR proposes to `target`. A routine
sub-branch PR targets the integration branch; the integration PR itself is always merged by a human.
Dependabot PRs keep targeting `target`, because Dependabot opens them there.
"""
import json
from pathlib import Path
import re
import subprocess

AUTO_PREFIX = 'forge/routine/auto/'
ROUTINE_PREFIX = 'forge/routine/'
LEGACY_PREFIX = 'routine/'  # before the forge/ prefix; held so a human retires them, never merged
DEPENDABOT_PREFIX = 'dependabot/'
DEPENDABOT_AUTHORS = {'app/dependabot', 'dependabot[bot]'}
BUMP = re.compile(r'\bfrom v?(\d+)(?:\.(\d+))?\S* to v?(\d+)(?:\.(\d+))?')
PR_FIELDS = ('number,title,url,author,headRefName,baseRefName,isDraft,mergeable,mergeStateStatus,'
             'reviewDecision,statusCheckRollup')
SEVERITIES = ('critical', 'high', 'medium', 'low')
ALERT_JQ = ('.[] | {severity: .security_advisory.severity, ghsa: .security_advisory.ghsa_id, '
            'package: .dependency.package.name, ecosystem: .dependency.package.ecosystem, '
            'scope: .dependency.scope, manifest: .dependency.manifest_path, '
            'fixed: .security_vulnerability.first_patched_version.identifier}')
PASSING = {'SUCCESS', 'NEUTRAL', 'SKIPPED'}
DEFAULT_INTEGRATION = 'forge/maintenance'


def run_command(argv, cwd=None):
    done = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=120)
    return done.returncode, done.stdout, done.stderr


def load_config(paths):
    path = paths.user / 'routines.json'
    if not path.is_file():
        raise ValueError(f'no routines config at {path}')
    repos = json.loads(path.read_text()).get('repos') or {}
    if not repos:
        raise ValueError(f'no repos in {path}')
    for name, repo in repos.items():
        missing = {'github', 'head', 'target'} - set(repo)
        if missing:
            raise ValueError(f'routines repo {name} lacks {sorted(missing)}')
    return repos


def integration_branch(repo):
    return repo.get('integration') or DEFAULT_INTEGRATION


def checks_verdict(rollup):
    """A PR with no checks has no proof: an empty rollup never passes."""
    if not rollup:
        return 'no CI checks on this PR'
    for check in rollup:
        name = check.get('name') or check.get('context') or 'check'
        if check.get('state'):
            result = check['state']
        elif check.get('status') not in (None, 'COMPLETED'):
            return f'{name} still running'
        else:
            result = check.get('conclusion')
        if result not in PASSING:
            return f'{name}: {result}'
    if not any((check.get('conclusion') or check.get('state')) == 'SUCCESS' for check in rollup):
        return 'no check actually succeeded'
    return None


def head_verdict(repo, run):
    """The user's rule: the integration checkout must be on target, clean and up to date."""
    head = str(Path(repo['head']).expanduser())
    target = repo['target']
    code, _, err = run(['git', '-C', head, 'fetch', '--quiet', 'origin', target])
    if code:
        return f'fetch failed: {err.strip()[:120]}'
    code, branch, _ = run(['git', '-C', head, 'branch', '--show-current'])
    if code or branch.strip() != target:
        return f'@head is on {branch.strip() or "a detached HEAD"}, not {target}'
    code, dirty, _ = run(['git', '-C', head, 'status', '--porcelain'])
    if code or dirty.strip():
        return f'@head has {len(dirty.splitlines())} uncommitted file(s)'
    code, counts, _ = run(['git', '-C', head, 'rev-list', '--left-right', '--count', f'HEAD...origin/{target}'])
    if code or int(counts.split()[0]):
        return f'@head has commits not on origin/{target}'
    return None


def is_dependabot(pr):
    return pr['headRefName'].startswith(DEPENDABOT_PREFIX)


def bump_verdict(pr):
    """Only a patch or minor bump, read from the title, merges unattended. Anything unreadable holds."""
    if (pr.get('author') or {}).get('login') not in DEPENDABOT_AUTHORS:
        return 'dependabot branch from another author'
    match = BUMP.search(pr.get('title') or '')
    if not match:
        return 'cannot read the version bump'
    old_major, old_minor, new_major, new_minor = match.groups()
    if old_major != new_major:
        return f'major bump {old_major} to {new_major}'
    if old_major == '0' and old_minor != new_minor:
        return f'0.x minor bump {old_minor} to {new_minor}'
    return None


def pr_verdict(pr, repo):
    """Gates that need only the PR. Returns the reason to hold, or None."""
    if is_dependabot(pr):
        reason = bump_verdict(pr)
        if reason:
            return reason
        if pr['baseRefName'] != repo['target']:
            return f'targets {pr["baseRefName"]}, not {repo["target"]}'
    else:
        if not pr['headRefName'].startswith(AUTO_PREFIX):
            return 'behaviour-changing routine: needs a human'
        integration = integration_branch(repo)
        if pr['baseRefName'] != integration:
            return f'targets {pr["baseRefName"]}, not the integration branch {integration}'
    if pr.get('isDraft'):
        return 'draft'
    if pr.get('reviewDecision') in ('CHANGES_REQUESTED', 'REVIEW_REQUIRED'):
        return f'review: {pr["reviewDecision"]}'
    if pr.get('mergeable') != 'MERGEABLE':
        return f'mergeable: {pr.get("mergeable")}'
    return checks_verdict(pr.get('statusCheckRollup') or [])


def behind_by(repo, pr, run):
    compare = f'repos/{repo["github"]}/compare/{pr["baseRefName"]}...{pr["headRefName"]}'
    code, out, _ = run(['gh', 'api', compare, '--jq', '.behind_by'])
    return int(out.strip()) if code == 0 and out.strip().isdigit() else None


def sweep(name, repo, apply=False, run=run_command):
    """Merge at most one PR. A merge moves the base, so the rest wait for fresh CI on the next sweep."""
    code, out, err = run(['gh', 'pr', 'list', '-R', repo['github'], '--state', 'open', '--limit', '100',
                          '--json', PR_FIELDS])
    if code:
        raise ValueError(f'{name}: gh pr list failed: {err.strip()[:160]}')
    integration = integration_branch(repo)
    prs = [pr for pr in json.loads(out)
           if pr['headRefName'] == integration
           or pr['headRefName'].startswith((ROUTINE_PREFIX, LEGACY_PREFIX, DEPENDABOT_PREFIX))]
    rows, merged = [], False
    policy_auto = repo.get('merge') == 'auto'
    for pr in sorted(prs, key=lambda item: item['number']):
        row = {'repo': name, 'pr': pr['number'], 'url': pr.get('url'), 'action': 'hold'}
        rows.append(row)
        if pr['headRefName'] == integration:
            row['reason'] = f'integration PR {integration} -> {pr["baseRefName"]}: a human merges it'
            continue
        if pr['headRefName'].startswith(LEGACY_PREFIX):
            row['reason'] = f'legacy branch name: bring it onto {integration}, or close it'
            continue
        if not policy_auto:
            row['reason'] = repo.get('merge_note') or 'repo policy: review'
            continue
        row['reason'] = pr_verdict(pr, repo)
        if row['reason']:
            continue
        if merged:
            row['reason'] = 'base moved this sweep; next sweep'
            continue
        behind = behind_by(repo, pr, run)
        if behind is None:
            row['reason'] = 'could not compare with base'
        elif behind:
            row['action'] = 'update' if apply else 'would-update'
            row['reason'] = f'{behind} commit(s) behind {pr["baseRefName"]}; CI must rerun'
            if apply:
                # Dependabot stops maintaining a branch someone else pushed to, so ask it to rebase.
                update = (['gh', 'pr', 'comment', str(pr['number']), '-R', repo['github'], '--body',
                           '@dependabot rebase'] if is_dependabot(pr)
                          else ['gh', 'pr', 'update-branch', str(pr['number']), '-R', repo['github']])
                code, _, err = run(update)
                if code:
                    row.update(action='hold', reason=f'update-branch failed: {err.strip()[:120]}')
        else:
            # Only a merge into target moves @head; the integration branch is checked out in @maintenance,
            # whose own run merges it forward.
            row['reason'] = head_verdict(repo, run) if pr['baseRefName'] == repo['target'] else None
            if row['reason']:
                continue
            merged = merge_one(pr, repo, row, apply, run)
    return rows


def merge_one(pr, repo, row, apply, run):
    if not apply:
        row.update(action='would-merge', reason='all gates pass')
        return False
    code, _, err = run(['gh', 'pr', 'merge', str(pr['number']), '-R', repo['github'], '--merge', '--delete-branch'])
    if code:
        row.update(action='hold', reason=f'merge failed: {err.strip()[:120]}')
        return False
    if pr['baseRefName'] != repo['target']:
        row.update(action='merged', reason=f'all gates passed; into {pr["baseRefName"]}')
        return True
    head = str(Path(repo['head']).expanduser())
    code, _, err = run(['git', '-C', head, 'pull', '--ff-only', 'origin', repo['target']])
    row.update(action='merged', reason='all gates passed' if code == 0 else f'merged; @head pull failed: {err.strip()[:100]}')
    return True


def security(name, repo, run=run_command):
    """Open Dependabot alerts grouped by package, worst first. A repo GitHub will not answer for says so."""
    code, out, err = run(['gh', 'api', '--paginate', f'repos/{repo["github"]}/dependabot/alerts?state=open&per_page=100',
                          '--jq', ALERT_JQ])
    if code:
        return {'repo': name, 'unavailable': (err or out).strip()[:160], 'alerts': 0, 'packages': []}
    alerts = [json.loads(line) for line in out.splitlines() if line.strip()]
    packages = {}
    for alert in alerts:
        key = (alert['ecosystem'], alert['package'])
        entry = packages.setdefault(key, {'ecosystem': key[0], 'package': key[1], 'alerts': 0, 'severity': 'low',
                                          'scopes': set(), 'fixed': set(), 'ghsa': set(), 'manifests': set()})
        entry['alerts'] += 1
        if SEVERITIES.index(alert['severity']) < SEVERITIES.index(entry['severity']):
            entry['severity'] = alert['severity']
        for field, value in (('scopes', alert.get('scope')), ('fixed', alert.get('fixed')),
                             ('ghsa', alert.get('ghsa')), ('manifests', alert.get('manifest'))):
            if value:
                entry[field].add(value)
    ranked = sorted(packages.values(), key=lambda item: (SEVERITIES.index(item['severity']),
                                                         'runtime' not in item['scopes'], -item['alerts'], item['package']))
    for entry in ranked:
        for field in ('scopes', 'fixed', 'ghsa', 'manifests'):
            entry[field] = sorted(entry[field])
    counts = {level: sum(1 for alert in alerts if alert['severity'] == level) for level in SEVERITIES}
    return {'repo': name, 'alerts': len(alerts), 'counts': counts, 'packages': ranked}


def render_security(report, top=15):
    if report.get('unavailable'):
        return f'{report["repo"]}: alerts unavailable: {report["unavailable"]}'
    counts = ' '.join(f'{level} {number}' for level, number in report['counts'].items())
    lines = [f'{report["repo"]}: {report["alerts"]} open alert(s): {counts}']
    for entry in report['packages'][:top]:
        fixed = ', '.join(entry['fixed']) or 'no fix published'
        lines.append(f'  {entry["severity"]} {entry["ecosystem"]}/{entry["package"]} x{entry["alerts"]} '
                     f'({"/".join(entry["scopes"]) or "unknown scope"}): fixed in {fixed}')
    return '\n'.join(lines)


def render(rows):
    if not rows:
        return 'no open routine PRs'
    return '\n'.join(f'{row["repo"]} #{row["pr"]} {row["action"]}: {row["reason"]}' for row in rows)
