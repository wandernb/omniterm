"""`forge storage`: the storage-hygiene doctrine's tooling (forge-storage-hygiene.md, guidelines S1–S4).

Read-only by design. It measures, flags and suggests; it never deletes. Deletion stays a human (or
session) decision, made one command at a time, or routed to a dedicated cleanup tool the user layer names.

- **Ledger** (`<forge>/state/storage-ledger.md`): one markdown table row per heavy item a session created.
  `add` appends a measured row, `done` marks one removed (or kept, with a reason), `ledger` lists and flags.
- **Report**: free space vs the floor, ledger rows that need action, and the biggest reclaimable items:
  known tool caches, VM and container stores, and regenerable build/dependency folders in idle projects.
- **Stop hook**: once per session, if this session's project has its own leftovers (expired ledger rows,
  heavy files nobody ledgered), ask it to clean them up silently. Global disk state never triggers it.

User config (optional, private): `<forge>/user/storage.json`
    {"roots": ["~/Projects"],                 # where to look for project build/dependency folders
     "protect": ["**/.next-s*"],              # globs never proposed for deletion
     "routes": [{"match": "~/x/dist/**", "suggest": "my-cleaner --category x --dry-run", "note": "..."}],
     "cleanup_tool": {"name": "...", "audit": "...", "reclaim": "..."}}
"""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import ctypes
from dataclasses import asdict, dataclass, field
import datetime as dt
import fcntl
import fnmatch
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import time

GB = 1024 ** 3
MB = 1024 ** 2
FLOOR_BYTES = 15 * GB
HEAVY_BYTES = 100 * MB

LEDGER_NAME = 'storage-ledger.md'
COLUMNS = ['Created', 'Path', 'Size', 'Kind', 'Project · session', 'What it is and why it is kept', 'Keep until', 'Status']
KINDS = ('dump', 'build', 'deps', 'cache', 'docker', 'vm', 'download', 'log', 'media', 'worktree', 'other')
LEDGER_HEADER = f"""# Storage Ledger

Machine-local record of heavy items agent sessions created. Doctrine: `~/.forge/knowledge/forge-storage-hygiene.md` (shared guidelines S1–S4).
Append a row per item when you create it (`forge storage add`); mark it when it goes (`forge storage done`). Never delete a row.

| {' | '.join(COLUMNS)} |
|{'|'.join('-' * (len(c) + 2) for c in COLUMNS)}|
"""

# Folders a project build or install recreates; safe to propose once the project is idle.
REGENERABLE = {
    'node_modules': 'deps', '.venv': 'deps', 'venv': 'deps', '.tox': 'deps', 'Pods': 'deps',
    '.next': 'build', '.nuxt': 'build', '.svelte-kit': 'build', '.turbo': 'cache', '.parcel-cache': 'cache',
    '.angular': 'cache', '.gradle': 'cache', '.pytest_cache': 'cache', '.mypy_cache': 'cache',
    '.ruff_cache': 'cache', 'coverage': 'build', 'target': 'build', 'DerivedData': 'build',
}
# Generic names that often hold more than build output (releases, VMs, data): inspect, never rm blind.
AMBIGUOUS = {'dist': 'build', 'build': 'build', 'out': 'build', 'tmp': 'other', 'log': 'log', 'logs': 'log',
             '.cache': 'cache', 'release': 'build', 'releases': 'build'}
SKIP_DIRS = {'.git', '.hg', '.svn', 'Library', '.Trash'}
VM_SUFFIXES = ('.utm', '.vmwarevm', '.pvm', '.qcow2', '.vmdk', '.vdi', '.ova', '.vhdx', '.raw', '.iso')

# (path under home, kind, action, suggestion, note). action: delete | tool | review.
KNOWN = [
    ('.npm/_cacache', 'cache', 'delete', 'npm cache clean --force', 'npm download cache; refills on install'),
    ('.npm/_npx', 'cache', 'delete', "rm -rf ~/.npm/_npx", 'npx one-off installs'),
    ('Library/Caches/Yarn', 'cache', 'delete', 'yarn cache clean', 'Yarn classic cache'),
    ('.yarn/berry/cache', 'cache', 'delete', 'yarn cache clean --all', 'Yarn Berry cache'),
    ('.bun/install/cache', 'cache', 'delete', 'bun pm cache rm', 'Bun download cache'),
    ('Library/pnpm/store', 'cache', 'delete', 'pnpm store prune', 'pnpm store (prune keeps what projects use)'),
    ('Library/Caches/pip', 'cache', 'delete', 'pip cache purge', 'pip wheel cache'),
    ('.cache/pip', 'cache', 'delete', 'pip cache purge', 'pip wheel cache'),
    ('.cache/uv', 'cache', 'delete', 'uv cache prune', 'uv cache (prune keeps what is in use)'),
    ('Library/Caches/Homebrew', 'cache', 'delete', 'brew cleanup --prune=all', 'Homebrew downloads'),
    ('Library/Caches/ms-playwright', 'cache', 'delete', 'npx playwright uninstall --all', 'Playwright browsers; tests re-download them'),
    ('.cache/ms-playwright', 'cache', 'delete', 'npx playwright uninstall --all', 'Playwright browsers; tests re-download them'),
    ('.cache/puppeteer', 'cache', 'delete', 'rm -rf ~/.cache/puppeteer', 'Puppeteer browsers; re-downloaded on install'),
    ('Library/Caches/electron', 'cache', 'delete', 'rm -rf ~/Library/Caches/electron', 'Electron downloads'),
    ('Library/Caches/electron-builder', 'cache', 'delete', 'rm -rf ~/Library/Caches/electron-builder', 'electron-builder downloads'),
    ('.gradle/caches', 'cache', 'delete', 'rm -rf ~/.gradle/caches', 'Gradle caches'),
    ('.m2/repository', 'cache', 'review', 'du -sh ~/.m2/repository', 'Maven repository; offline builds need it'),
    ('go/pkg/mod', 'cache', 'delete', 'go clean -modcache', 'Go module cache'),
    ('.cargo/registry', 'cache', 'review', 'cargo cache --autoclean  # needs cargo-cache', 'Cargo registry'),
    ('Library/Developer/Xcode/DerivedData', 'build', 'delete', 'rm -rf ~/Library/Developer/Xcode/DerivedData/*', 'Xcode build products'),
    ('Library/Developer/Xcode/iOS DeviceSupport', 'cache', 'review', "open ~/Library/Developer/Xcode/'iOS DeviceSupport'", 'per-iOS-version symbols; keep current versions'),
    ('Library/Developer/CoreSimulator/Devices', 'vm', 'review', 'xcrun simctl delete unavailable', 'simulators; removes only unavailable ones'),
    ('Library/Containers/com.docker.docker', 'docker', 'review', 'docker system df -v', 'Docker Desktop disk; reclaim inside Docker, never delete the file'),
    ('.orbstack', 'docker', 'review', 'docker system df -v', 'OrbStack data; reclaim inside it'),
    ('.colima', 'docker', 'review', 'docker system df -v', 'Colima VM disk'),
    ('Library/Containers/com.utmapp.UTM/Data/Documents', 'vm', 'review', 'open -a UTM', 'UTM virtual machines'),
    ('Parallels', 'vm', 'review', 'open -a "Parallels Desktop"', 'Parallels virtual machines'),
    ('VirtualBox VMs', 'vm', 'review', 'VBoxManage list vms', 'VirtualBox virtual machines'),
    ('.Trash', 'other', 'delete', 'Empty the Trash in Finder', 'already-deleted files still on disk'),
]


# ---------------------------------------------------------------------------- helpers

def human(size):
    if size is None:
        return '?'
    for unit, scale in (('TB', 1024 ** 4), ('GB', GB), ('MB', MB), ('KB', 1024)):
        if size >= scale:
            return f'{size / scale:.1f} {unit}'
    return f'{size} B'


def parse_size(text):
    match = re.fullmatch(r'\s*([\d.]+)\s*([KMGT]?)B?\s*', str(text), re.I)
    if not match:
        raise ValueError(f'unreadable size: {text!r} (use e.g. 200M, 2G)')
    scale = {'': 1, 'K': 1024, 'M': MB, 'G': GB, 'T': 1024 ** 4}[match.group(2).upper()]
    return int(float(match.group(1)) * scale)


def tilde(path, home):
    text = str(path)
    return '~' + text[len(str(home)):] if text == str(home) or text.startswith(str(home) + '/') else text


def expand(text, home):
    text = str(text).strip()
    if text == '~' or text.startswith('~/'):
        return Path(str(home) + text[1:])
    return Path(text)


def local_path(text, home):
    """The local Path a ledger cell names, or None when it can't be checked here (docker://, ssh://,
    brace globs, elisions, several paths in one cell)."""
    text = str(text).strip()
    if not text.startswith(('/', '~')) or any(mark in text for mark in ('{', '*', '…', ' + ', '://')):
        return None
    return expand(text, home)


def measure(path, timeout=120):
    """Allocated bytes under path (du -sk: hard links once, sparse files by blocks). None if unknown."""
    try:
        if path.is_file() and not path.is_symlink():
            return path.stat().st_blocks * 512
        result = subprocess.run(['du', '-sk', str(path)], capture_output=True, text=True, timeout=timeout)
        first = result.stdout.split('\t', 1)[0].strip()
        return int(first) * 1024 if first.isdigit() else None
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return None


def _macos_available(path):
    """NSURL's important-usage capacity, through the Objective-C runtime: stdlib has no other route."""
    objc = ctypes.CDLL('/usr/lib/libobjc.A.dylib')
    ctypes.CDLL('/System/Library/Frameworks/Foundation.framework/Foundation')
    objc.objc_getClass.restype = objc.sel_registerName.restype = ctypes.c_void_p
    objc.objc_getClass.argtypes = objc.sel_registerName.argtypes = [ctypes.c_char_p]
    pointer = ctypes.c_void_p

    def send(*arguments, result=pointer):
        return ctypes.CFUNCTYPE(result, pointer, pointer, *arguments)(('objc_msgSend', objc))

    def string(text):
        return send(ctypes.c_char_p)(objc.objc_getClass(b'NSString'),
                                     objc.sel_registerName(b'stringWithUTF8String:'), text)

    url = send(pointer)(objc.objc_getClass(b'NSURL'), objc.sel_registerName(b'fileURLWithPath:'),
                        string(str(path).encode()))
    value = pointer()
    read = send(ctypes.POINTER(pointer), pointer, pointer, result=ctypes.c_bool)
    key = string(b'NSURLVolumeAvailableCapacityForImportantUsageKey')
    if not url or not read(url, objc.sel_registerName(b'getResourceValue:forKey:error:'),
                           ctypes.byref(value), key, None) or not value:
        return None
    return send(result=ctypes.c_longlong)(value, objc.sel_registerName(b'longLongValue'))


def disk(path):
    """The floor is judged on `available`. `df` and shutil.disk_usage omit purgeable space, so on a Mac
    they report tens of GB less than Finder and raise false low-disk alarms."""
    usage = shutil.disk_usage(path)
    available = None
    if sys.platform == 'darwin':
        try:
            available = _macos_available(path)
        except (OSError, AttributeError, ValueError):
            available = None
    available = max(available or 0, usage.free)  # A failed reading must not claim less than is empty.
    return {'path': str(path), 'total': usage.total, 'free': usage.free, 'available': available,
            'purgeable': available - usage.free, 'floor': FLOOR_BYTES, 'low': available < FLOOR_BYTES}


def load_config(paths):
    config_path = paths.user / 'storage.json'
    config = {'roots': ['~/Projects'], 'protect': [], 'routes': [], 'cleanup_tool': None}
    if config_path.is_file():
        config.update(json.loads(config_path.read_text()))
    return config


def _matches(path, pattern, home):
    pattern = str(expand(pattern, home))
    text = str(path)
    return fnmatch.fnmatch(text, pattern) or fnmatch.fnmatch(text + '/', pattern) \
        or (pattern.endswith('/**') and (text == pattern[:-3] or text.startswith(pattern[:-2])))


def protected(path, config, home):
    return any(_matches(path, pattern, home) for pattern in config.get('protect', []))


def route(path, config, home):
    for entry in config.get('routes', []):
        if _matches(path, entry['match'], home):
            return entry
    return None


def project_root(path):
    for parent in [path, *path.parents]:
        if (parent / '.git').exists():
            return parent
    return None


def last_activity(root):
    """Newest of the git index/HEAD mtimes: a cheap 'when was this checkout last worked in'."""
    git = root / '.git'
    try:
        if git.is_file():
            pointer = git.read_text().strip()
            git = Path(pointer.split(':', 1)[1].strip()) if pointer.startswith('gitdir:') else git
            if not git.is_absolute():
                git = (root / git).resolve()
        times = [p.stat().st_mtime for p in (git / 'index', git / 'HEAD', git / 'FETCH_HEAD') if p.exists()]
        return max(times) if times else root.stat().st_mtime
    except OSError:
        return None


def folder_activity(folder, exclude):
    """Without git: newest mtime among the folder's own top-level entries, the candidate excluded."""
    times = []
    for child in _children(folder):
        if child.path != str(exclude):
            try:
                times.append(child.stat(follow_symlinks=False).st_mtime)
            except OSError:
                continue
    return max(times) if times else None


def tracked(root, path):
    """True when git tracks anything under path (so it is source, not output)."""
    try:
        result = subprocess.run(['git', '-C', str(root), 'ls-files', '--', str(path.relative_to(root))],
                                capture_output=True, text=True, timeout=20)
        return bool(result.stdout.strip())
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return True  # can't tell -> treat as source


# ---------------------------------------------------------------------------- ledger

@contextmanager
def _ledger_lock(paths):
    paths.state_dir.mkdir(parents=True, exist_ok=True)
    with open(paths.state_dir / 'storage-ledger.lock', 'w') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def ledger_path(paths):
    return paths.state_dir / LEDGER_NAME


def _cells(line):
    inner = line.strip()[1:-1]
    return [cell.strip().replace('\\|', '|') for cell in re.split(r'(?<!\\)\|', inner)]


def _escape(text):
    return str(text).replace('|', '\\|').replace('\n', ' ').strip()


def read_ledger(paths):
    """Rows as dicts (with 'line' = index into the file's lines). Missing file -> []."""
    path = ledger_path(paths)
    if not path.exists():
        return [], []
    lines = path.read_text().splitlines()
    rows = []
    for index, line in enumerate(lines):
        if not line.strip().startswith('|'):
            continue
        cells = _cells(line)
        if len(cells) != len(COLUMNS) or cells[0] == COLUMNS[0] or set(cells[0]) <= {'-', ' ', ':'}:
            continue
        row = dict(zip(COLUMNS, cells))
        row['line'] = index
        rows.append(row)
    return lines, rows


def _format_row(row):
    return '| ' + ' | '.join(_escape(row[c]) for c in COLUMNS) + ' |'


def _ensure(paths):
    path = ledger_path(paths)
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(LEDGER_HEADER)


def detect_project(cwd):
    root = project_root(cwd)
    return (root or cwd).name


def add(paths, item, why, kind='other', until='end of session', project=None, session=None, cwd=None,
        today=None):
    """Append a measured row. Returns the row. Refuses a path that has a `present` row already."""
    home = paths.home
    cwd = Path(cwd or os.getcwd())
    target = expand(item, home)
    target = target if target.is_absolute() else (cwd / target)
    target = Path(os.path.abspath(target))
    if not target.exists():
        raise ValueError(f'{target} does not exist; ledger an item once it is created')
    if kind not in KINDS:
        raise ValueError(f'kind must be one of {", ".join(KINDS)}')
    if not why.strip():
        raise ValueError('--why is required: what it is and why it is kept')
    label = project or detect_project(cwd)
    if session:
        label = f'{label} · {session}'
    row = {'Created': (today or dt.date.today()).isoformat(), 'Path': tilde(target, home),
           'Size': human(measure(target)), 'Kind': kind, 'Project · session': label,
           'What it is and why it is kept': why, 'Keep until': until, 'Status': 'present'}
    with _ledger_lock(paths):
        _ensure(paths)
        _, rows = read_ledger(paths)
        if any(local_path(r['Path'], home) == target and r['Status'].lower().startswith('present') for r in rows):
            raise ValueError(f'{row["Path"]} already has a present ledger row; update it with `forge storage done`')
        text = ledger_path(paths).read_text()
        ledger_path(paths).write_text(text + ('' if text.endswith('\n') else '\n') + _format_row(row) + '\n')
    return row


def done(paths, item, keep=None, cwd=None, today=None):
    """Mark the present row(s) for item removed (path must be gone) or kept (with a reason)."""
    home = paths.home
    cwd = Path(cwd or os.getcwd())
    target = None
    if '://' not in item:
        target = expand(item, home)
        target = Path(os.path.abspath(target if target.is_absolute() else cwd / target))
    key = tilde(target, home) if target else item
    stamp = (today or dt.date.today()).isoformat()
    with _ledger_lock(paths):
        lines, rows = read_ledger(paths)
        hits = [r for r in rows
                if (r['Path'] == item or (target is not None and local_path(r['Path'], home) == target))
                and r['Status'].lower().startswith(('present', 'kept'))]
        if not hits:
            raise ValueError(f'no present ledger row for {key}')
        if keep is None and target is not None and target.exists():
            raise ValueError(f'{key} still exists: delete it first, or pass --keep "<reason>"')
        for row in hits:
            row['Status'] = f'kept {stamp} — {keep}' if keep is not None else f'removed {stamp}'
            lines[row['line']] = _format_row(row)
        ledger_path(paths).write_text('\n'.join(lines) + '\n')
    return hits


_DATE = re.compile(r'(\d{4}-\d{2}-\d{2})')


def assess(row, home, today=None, review_days=14):
    """(state, reason) for a ledger row: ok | expired | gone | review | done."""
    today = today or dt.date.today()
    status = row['Status'].lower()
    if status.startswith('removed'):
        return 'done', ''
    present_path = local_path(row['Path'], home)
    if present_path is not None and not present_path.exists():
        return 'gone', 'path no longer exists: mark it removed'
    if status.startswith('kept'):
        return 'ok', row['Status']
    until = row['Keep until'].strip().lower()
    try:
        created = dt.date.fromisoformat(row['Created'][:10])
    except ValueError:
        created = today
    if until.startswith('permanent'):
        return 'ok', 'permanent'
    if until in ('end of session', 'session', 'end-of-session'):
        return ('expired', 'end-of-session item from an earlier day') if created < today else ('ok', 'this session')
    date = _DATE.search(until)
    if date:
        try:
            return ('expired', f'keep-until {date.group(1)} has passed') if dt.date.fromisoformat(date.group(1)) < today \
                else ('ok', f'until {date.group(1)}')
        except ValueError:
            pass
    age = (today - created).days
    return ('review', f'condition "{row["Keep until"]}" set {age} days ago: still true?') if age >= review_days \
        else ('ok', row['Keep until'])


# ---------------------------------------------------------------------------- report

@dataclass
class Item:
    path: str
    size: int
    kind: str
    action: str          # delete | tool | review
    suggest: str
    note: str = ''
    source: str = ''     # known | project | docker | ledger
    age_days: int | None = None
    extra: dict = field(default_factory=dict)


def _apply_route(item, config, home):
    entry = route(expand(item.path, home), config, home)
    if entry:
        item.action, item.suggest = entry.get('action', 'tool'), entry['suggest']
        item.note = entry.get('note', item.note)
    return item


def scan_known(home, config, min_size):
    found = []
    candidates = [(home / rel, kind, action, suggest, note) for rel, kind, action, suggest, note in KNOWN]
    candidates = [c for c in candidates if c[0].exists() and not c[0].is_symlink()]
    with ThreadPoolExecutor(max_workers=6) as pool:
        sizes = list(pool.map(lambda c: measure(c[0]), candidates))
    for (path, kind, action, suggest, note), size in zip(candidates, sizes):
        if size is None or size < min_size or protected(path, config, home):
            continue
        found.append(_apply_route(Item(tilde(path, home), size, kind, action, suggest, note, 'known'), config, home))
    return found


def _walk(root, max_depth):
    """Yield (path, name) of candidate folders, never descending into them or into SKIP_DIRS."""
    stack = [(root, 0)]
    while stack:
        current, depth = stack.pop()
        try:
            entries = list(os.scandir(current))
        except OSError:
            continue
        for entry in entries:
            if not entry.is_dir(follow_symlinks=False) or entry.name in SKIP_DIRS:
                continue
            path = Path(entry.path)
            if entry.name in REGENERABLE or entry.name in AMBIGUOUS:
                yield path, entry.name
            elif depth + 1 < max_depth:
                stack.append((path, depth + 1))


def scan_projects(home, config, roots, min_size, idle_days, max_depth=6, budget=240, now=None):
    now = now or time.time()
    candidates = []
    for root in roots:
        root = expand(root, home)
        if root.is_dir():
            candidates += list(_walk(root, max_depth))
    deadline = time.time() + budget

    def size_of(candidate):
        return measure(candidate[0], timeout=max(1, int(deadline - time.time()))) if time.time() < deadline else None

    with ThreadPoolExecutor(max_workers=8) as pool:
        sizes = list(pool.map(size_of, candidates))
    found, skipped = [], {'active': 0, 'tracked': 0, 'protected': 0, 'unmeasured': 0}
    for (path, name), size in zip(candidates, sizes):
        if size is None:
            skipped['unmeasured'] += 1
            continue
        if size < min_size:
            continue
        if protected(path, config, home):
            skipped['protected'] += 1
            continue
        root = project_root(path.parent)
        activity = last_activity(root) if root else folder_activity(path.parent, path)
        age = int((now - activity) // 86400) if activity else None
        if root and tracked(root, path):
            skipped['tracked'] += 1
            continue
        kind = REGENERABLE.get(name) or AMBIGUOUS[name]
        quoted = shlex.quote(str(path))
        if name in REGENERABLE:
            if age is not None and age < idle_days:
                skipped['active'] += 1
                continue
            item = Item(tilde(path, home), size, kind, 'delete', f'rm -rf {quoted}',
                        f'regenerable {name}; project idle {age} days' if age is not None else f'regenerable {name}',
                        'project', age)
        else:
            vms = _vm_images(path)
            note = f'holds VM images ({", ".join(vms[:3])}): never rm blind' if vms else \
                f'"{name}" may hold releases, data or VMs: inspect before deleting'
            kind = 'vm' if vms else kind
            item = Item(tilde(path, home), size, kind, 'review', f'du -sh {quoted}/* | sort -h', note, 'project', age)
        found.append(_apply_route(item, config, home))
    return found, skipped


def _vm_images(path, depth=2):
    """Names of VM bundles/disk images within `depth` levels: a folder holding them is never rm-blind."""
    found, stack = [], [(path, 0)]
    while stack and len(found) < 3:
        current, level = stack.pop()
        for child in _children(current):
            if child.name.endswith(VM_SUFFIXES):
                found.append(child.name)
            elif level + 1 < depth and child.is_dir(follow_symlinks=False):
                stack.append((Path(child.path), level + 1))
    return found


def _children(path):
    try:
        return list(os.scandir(path))
    except OSError:
        return []


def scan_docker(timeout=8):
    """Docker's own accounting (images, containers, volumes, build cache). [] when Docker is absent/down."""
    if not shutil.which('docker'):
        return []
    try:
        result = subprocess.run(['docker', 'system', 'df', '--format', '{{json .}}'],
                                capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return []
    items = []
    advice = {
        'Images': ('review', 'docker image prune  # dangling only; `docker image ls` before anything wider'),
        'Containers': ('review', 'docker container ls -a --filter status=exited'),
        'Local Volumes': ('review', 'docker volume ls -f dangling=true  # volumes hold data: inspect, never prune blind'),
        'Build Cache': ('delete', 'docker builder prune --filter until=72h'),
    }
    for line in result.stdout.splitlines():
        try:
            row = json.loads(line)
            reclaimable = parse_size(row.get('Reclaimable', '0B').split(' ')[0])
        except (ValueError, json.JSONDecodeError):
            continue
        action, suggest = advice.get(row.get('Type'), ('review', 'docker system df -v'))
        if reclaimable >= HEAVY_BYTES:
            items.append(Item(f'docker:{row.get("Type")}', reclaimable, 'docker', action, suggest,
                              f'{row.get("Size")} total, {row.get("Reclaimable")} reclaimable per Docker '
                              '(internal figure, not promised host space)', 'docker'))
    return items


def ledger_findings(paths, today=None):
    _, rows = read_ledger(paths)
    findings = []
    for row in rows:
        state, reason = assess(row, paths.home, today)
        if state in ('expired', 'gone', 'review'):
            findings.append({**{k: v for k, v in row.items() if k != 'line'}, 'state': state, 'reason': reason})
    return rows, findings


def report(paths, roots=None, min_size=200 * MB, idle_days=14, projects=True, docker=True, today=None):
    config = load_config(paths)
    home = paths.home
    rows, findings = ledger_findings(paths, today)
    items = scan_known(home, config, min_size)
    skipped = {}
    if projects:
        project_items, skipped = scan_projects(home, config, roots or config['roots'], min_size, idle_days)
        items += project_items
    if docker:
        items += [_apply_route(item, config, home) for item in scan_docker()]
    items.sort(key=lambda item: item.size, reverse=True)
    return {'disk': disk(home), 'ledger_rows': len(rows), 'ledger_findings': findings, 'items': items,
            'skipped': skipped, 'cleanup_tool': config.get('cleanup_tool'), 'config': str(paths.user / 'storage.json')}


def render(result, home, top=25):
    out = []
    d = result['disk']
    pct = d['available'] / d['total'] * 100
    flag = '  ⚠ BELOW FLOOR' if d['low'] else ''
    out.append(f'Disk  {human(d["available"])} available of {human(d["total"])} ({pct:.0f} %; {human(d["free"])} empty now, '
               f'{human(d["purgeable"])} purgeable), floor {human(d["floor"])}{flag}')
    out.append('')
    findings = result['ledger_findings']
    out.append(f'Ledger  {result["ledger_rows"]} row(s), {len(findings)} need action')
    for f in findings:
        local = local_path(f['Path'], home) is not None
        remove = f'rm -rf {shlex.quote(str(local_path(f["Path"], home)))}' if local else 'remove it where it lives'
        verb = {'gone': f'forge storage done {shlex.quote(f["Path"])}',
                'expired': f'{remove}  &&  forge storage done {shlex.quote(f["Path"])}',
                'review': f'forge storage done {shlex.quote(f["Path"])} --keep "<still needed because…>"'}[f['state']]
        out.append(f'  [{f["state"]}] {f["Path"]}  {f["Size"]}  ({f["Project · session"]}) — {f["reason"]}')
        out.append(f'      why: {f["What it is and why it is kept"]}')
        out.append(f'      → {verb}')
    out.append('')
    items = result['items'][:top]
    total = {a: sum(i.size for i in result['items'] if i.action == a) for a in ('delete', 'tool', 'review')}
    out.append(f'Reclaimable  {human(total["delete"])} deletable · {human(total["tool"])} via cleanup tool · '
               f'{human(total["review"])} to review  (top {len(items)} of {len(result["items"])}, nothing deleted)')
    for item in items:
        age = f', idle {item.age_days}d' if item.age_days is not None else ''
        out.append(f'  {human(item.size):>9}  {item.action:<6} {item.kind:<8} {item.path}{age}')
        if item.note:
            out.append(f'             {item.note}')
        out.append(f'             → {item.suggest}')
    skipped = {k: v for k, v in result['skipped'].items() if v}
    if skipped:
        out.append('  skipped: ' + ', '.join(f'{v} {k}' for k, v in skipped.items())
                   + ' (active = project used recently; tracked = git tracks it; protected = storage.json)')
    tool = result.get('cleanup_tool')
    if tool:
        out.append('')
        out.append(f'Cleanup tool  {tool.get("name", "")}')
        for key in ('audit', 'reclaim'):
            if tool.get(key):
                out.append(f'  {key}: {tool[key]}')
    out.append('')
    out.append('Read-only: review each command before running it. Delete only what you own (S3).')
    return '\n'.join(out)


# ---------------------------------------------------------------------------- stop hook

def free_line(d):
    """The one line a session needs before heavy work; the full report is for when the user asks."""
    return f'{human(d["available"])} available (floor {human(d["floor"])}){", LOW" if d["low"] else ""}'


def _session_marker(paths, session_id):
    safe = re.sub(r'[^A-Za-z0-9_.-]', '_', session_id or 'unknown')[:80]
    return paths.state_dir / 'storage-hook' / safe


def _prune_markers(directory, days=7):
    cutoff = time.time() - days * 86400
    for marker in directory.glob('*') if directory.is_dir() else []:
        try:
            if marker.stat().st_mtime < cutoff:
                marker.unlink()
        except OSError:
            pass


def _fresh_heavy_files(cwd, ledgered, hours=24, min_size=None):
    """Big files modified in the last day in the project's scratch spots that no ledger row covers."""
    hits = []
    min_size = HEAVY_BYTES if min_size is None else min_size
    cutoff = time.time() - hours * 3600
    for spot in ('tmp', 'log', 'logs', '.tmp'):
        base = cwd / spot
        if not base.is_dir():
            continue
        stack, seen = [(base, 0)], 0
        while stack and seen < 2000:
            current, depth = stack.pop()
            for entry in _children(current):
                seen += 1
                try:
                    if entry.is_dir(follow_symlinks=False) and depth < 2:
                        stack.append((Path(entry.path), depth + 1))
                    elif entry.is_file(follow_symlinks=False):
                        stat = entry.stat(follow_symlinks=False)
                        if stat.st_blocks * 512 >= min_size and stat.st_mtime >= cutoff \
                                and not any(entry.path.startswith(p) for p in ledgered):
                            hits.append((entry.path, stat.st_blocks * 512))
                except OSError:
                    continue
    return hits


def stop_check(paths, payload, today=None):
    """The reason text when this session should do a storage pass before stopping, else None."""
    if payload.get('stop_hook_active'):
        return None
    marker = _session_marker(paths, payload.get('session_id'))
    if marker.exists():
        return None
    home = paths.home
    cwd = Path(payload.get('cwd') or os.getcwd())
    root = project_root(cwd) or cwd
    _, rows = read_ledger(paths)
    session_id = payload.get('session_id') or ''
    mine = []
    for row in rows:
        path = local_path(row['Path'], home)
        here = path is not None and (path == root or str(path).startswith(str(root) + '/'))
        if here or (session_id and session_id in row['Project · session']):
            state, reason = assess(row, home, today)
            if state in ('expired', 'gone'):
                mine.append(f'- [{state}] {row["Path"]} ({row["Size"]}): {reason}')
    ledgered = [str(local_path(r['Path'], home)) for r in rows
                if local_path(r['Path'], home) is not None and not r['Status'].lower().startswith('removed')]
    fresh = _fresh_heavy_files(root, ledgered)
    if not (mine or fresh):
        return None
    lines = ['Tidy your own leftovers before you stop (forge storage hygiene, S1–S4). Do this once, then finish:']
    if mine:
        lines.append('- Ledger rows for this project need action (delete what you own, or keep with a reason):')
        lines += [f'  {m}' for m in mine[:10]]
        lines.append('  Close each with `forge storage done <path>` (or `--keep "<reason>"`).')
    if fresh:
        lines.append('- Heavy files written in the last day that no ledger row covers:')
        lines += [f'  - {tilde(Path(p), home)} ({human(s)})' for p, s in fresh[:10]]
        lines.append('  Delete them if this session made them and no longer needs them; otherwise ledger them: '
                     '`forge storage add <path> --kind <kind> --why "<what and why>" --until "<when>"`.')
    lines.append('Only touch what this session created, and do it silently: no disk totals, no reclaimable lists, '
                 'nothing about other sessions. If nothing applies, just stop.')
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(dt.datetime.now().isoformat())
    _prune_markers(marker.parent)
    return '\n'.join(lines)


def stop_hook(paths, stdin=None):
    """Stop-hook entry: print a block decision when a storage pass is due. Never fails the session."""
    try:
        raw = (stdin or sys.stdin).read()
        payload = json.loads(raw) if raw.strip() else {}
        reason = stop_check(paths, payload)
        if reason:
            print(json.dumps({'decision': 'block', 'reason': reason}))
    except Exception:  # noqa: BLE001 - storage advice must never break a harness session
        pass
    return 0


def to_json(result):
    return json.dumps({**result, 'items': [asdict(i) for i in result['items']]}, indent=2, default=str)
