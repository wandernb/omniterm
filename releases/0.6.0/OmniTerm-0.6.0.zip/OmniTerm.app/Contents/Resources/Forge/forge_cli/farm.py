"""The resolved farm at ~/.forge/{commands,agents,knowledge,...}: one stable path per file.

Each farm entry links to ~/.forge/core/<rel> or ~/.forge/user/<rel>; ~/.forge/core links to the
repo's core/ (dev mode), so moving the repo only needs `forge link` again.
"""
from . import layers, linker

GROUP = 'farm'


def resolved(paths):
    return layers.resolve(paths.core_source, paths.user)


def ops(paths):
    result = [linker.symlink(paths.core, paths.core_source)]
    for rel, layer in resolved(paths).items():
        source_root = paths.core if layer == layers.CORE else paths.user
        result.append(linker.symlink(paths.forge_home / rel, source_root / rel))
    return result
