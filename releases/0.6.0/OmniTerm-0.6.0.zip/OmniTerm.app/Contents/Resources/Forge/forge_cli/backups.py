"""Timestamped copies of global config files, kept under ~/.forge/state/backups (never beside them)."""
from datetime import datetime
import shutil


def keep(path, backup_dir):
    """Copy path into backup_dir as <parent>__<name>.<stamp> (parent without its leading dot); return the copy's path."""
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    dest = backup_dir / f"{path.parent.name.lstrip('.')}__{path.name}.{stamp}"
    shutil.copy2(path, dest)
    return dest
