"""Plan and apply link/write operations, refusing to touch anything forge does not own.

Every op belongs to a group (`farm`, `claude:forgex`, `codex:forgex`, `launchd`, …). Applying a
group's ops also removes entries the group owned before but no longer plans (rename/delete), but
only if they are still exactly what forge wrote.
"""
from dataclasses import dataclass
import os
from pathlib import Path

from . import state as state_mod


class ConflictError(Exception):
    def __init__(self, conflicts):
        self.conflicts = conflicts
        lines = '\n'.join(f'  {path}: {why}' for path, why in conflicts)
        super().__init__(f'Refusing to change anything; {len(conflicts)} conflict(s):\n{lines}')


@dataclass(frozen=True)
class Op:
    kind: str  # 'symlink' | 'file' | 'dir'
    path: Path
    target: str = None
    content: str = None

    def record(self, group):
        entry = {'kind': self.kind, 'group': group}
        if self.kind == 'symlink':
            entry['target'] = self.target
        elif self.kind == 'file':
            entry['sha256'] = state_mod.sha256(self.content)
        return entry


def symlink(path, target):
    return Op('symlink', Path(path), target=str(target))


def file(path, content):
    return Op('file', Path(path), content=content)


def directory(path):
    return Op('dir', Path(path))


def matches(path, entry):
    """Is the path on disk still exactly what the state entry says forge put there?"""
    kind = entry['kind']
    if kind == 'symlink':
        return path.is_symlink() and os.readlink(path) == entry['target']
    if kind == 'file':
        return (path.is_file() and not path.is_symlink()
                and state_mod.sha256(path.read_bytes()) == entry['sha256'])
    if kind == 'dir':
        return path.is_dir() and not path.is_symlink()
    return False


def _status(op, entries):
    path = op.path
    exists = path.exists() or path.is_symlink()
    owned = entries.get(str(path))
    if op.kind == 'symlink':
        if path.is_symlink() and os.readlink(path) == op.target:
            return 'ok'
    elif op.kind == 'file':
        if path.is_file() and not path.is_symlink() and path.read_text() == op.content:
            return 'ok'
    elif op.kind == 'dir':
        if path.is_dir() and not path.is_symlink():
            return 'ok'
    if not exists:
        return 'create'
    if owned and owned['kind'] == op.kind and matches(path, owned):
        return 'update'
    return 'conflict'


def _parents(op, entries, planned):
    """Missing parent directories to create (and own) before the op."""
    missing = []
    parent = op.path.parent
    while not parent.exists() and str(parent) not in planned:
        missing.append(directory(parent))
        parent = parent.parent
    return list(reversed(missing))


def plan(ops, group, current_state):
    """Return (actions, removals): actions are (status, op); removals are stale owned paths."""
    entries = current_state['entries']
    planned = {}
    for op in ops:
        for parent in _parents(op, entries, planned):
            planned.setdefault(str(parent.path), parent)
        planned[str(op.path)] = op
    actions = [(_status(op, entries), op) for op in planned.values()]
    conflicts = [(op.path, _why(op)) for status, op in actions if status == 'conflict']
    if conflicts:
        raise ConflictError(conflicts)
    # Owned parent dirs that still contain planned paths stay owned, even though they now exist.
    ancestors = {str(parent) for p in planned for parent in Path(p).parents}
    removals = [Path(p) for p, entry in entries.items()
                if entry['group'] == group and p not in planned
                and not (entry['kind'] == 'dir' and p in ancestors)]
    return actions, removals


def _why(op):
    path = op.path
    if path.is_symlink():
        return f'existing symlink -> {os.readlink(path)} (not owned by forge)'
    if path.is_dir():
        return 'existing directory not owned by forge'
    return 'existing file not owned by forge (or modified since forge wrote it)'


def _atomic_symlink(path, target):
    tmp = path.with_name(f'.{path.name}.forge-tmp')
    if tmp.is_symlink() or tmp.exists():
        tmp.unlink()
    os.symlink(target, tmp)
    os.replace(tmp, path)


def _atomic_write(path, content):
    tmp = path.with_name(f'.{path.name}.forge-tmp')
    tmp.write_text(content)
    os.replace(tmp, path)


def remove_owned(paths, current_state, report):
    """Remove owned paths that still match their record; dirs last, deepest first, only if empty."""
    entries = current_state['entries']
    ordered = sorted(paths, key=lambda p: (entries[str(p)]['kind'] == 'dir', -len(p.parts)))
    for path in ordered:
        entry = entries[str(path)]
        if not (path.exists() or path.is_symlink()):
            del entries[str(path)]
            continue
        if not matches(path, entry):
            report.append(f'kept (changed since forge wrote it): {path}')
            del entries[str(path)]
            continue
        if entry['kind'] == 'dir':
            if any(path.iterdir()):
                report.append(f'kept (not empty): {path}')
                del entries[str(path)]
                continue
            path.rmdir()
        else:
            path.unlink()
        del entries[str(path)]
        report.append(f'removed: {path}')


def apply(ops, group, current_state, dry_run=False):
    """Plan, then (unless dry_run) execute. Mutates current_state; caller saves it."""
    actions, removals = plan(ops, group, current_state)
    report = []
    changes = [(status, op) for status, op in actions if status != 'ok']
    if dry_run:
        report += [f'would {status}: {op.path}' for status, op in changes]
        report += [f'would remove: {path}' for path in removals]
        return report
    entries = current_state['entries']
    for status, op in actions:
        if status != 'ok':
            if op.kind == 'dir':
                op.path.mkdir()
            elif op.kind == 'symlink':
                _atomic_symlink(op.path, op.target)
            else:
                _atomic_write(op.path, op.content)
            report.append(f'{status}: {op.path}')
        # A path that already matched before forge touched it stays the user's: only what forge
        # created or replaced, or already owned, is recorded (and so removable by uninstall).
        if status != 'ok' or str(op.path) in entries:
            entries[str(op.path)] = op.record(group)
    remove_owned(removals, current_state, report)
    return report


def uninstall(groups, current_state, dry_run=False):
    paths = [Path(p) for p, e in current_state['entries'].items() if e['group'] in groups]
    if dry_run:
        return [f'would remove: {p}' for p in paths]
    report = []
    remove_owned(paths, current_state, report)
    return report


def check(current_state):
    """Problems with owned entries: missing, changed, or dangling links."""
    problems = []
    for p, entry in sorted(current_state['entries'].items()):
        path = Path(p)
        if not (path.exists() or path.is_symlink()):
            problems.append(f'missing: {path}')
        elif not matches(path, entry):
            problems.append(f'changed since forge wrote it: {path}')
        elif entry['kind'] == 'symlink' and not path.exists():
            problems.append(f'dangling link: {path} -> {entry["target"]}')
    return problems
