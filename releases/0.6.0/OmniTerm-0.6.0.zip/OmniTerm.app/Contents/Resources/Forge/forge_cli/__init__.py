"""forge — install, layer and link the forge command suite into agent harnesses."""

__version__ = '0.1.0.dev0'
