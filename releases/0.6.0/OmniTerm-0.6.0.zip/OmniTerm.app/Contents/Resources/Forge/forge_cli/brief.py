"""The forge session brief: a ≤1000-character template printed by the SessionStart hook, plus one
exposure line and any health line.

Both harnesses add a SessionStart hook's stdout to the context after the global AGENTS.md/CLAUDE.md
and before the first prompt; the `compact` matcher re-adds it after compaction.
"""
LIMIT = 1000


def _tilde(path, home):
    text = str(path)
    return '~' + text[len(str(home)):] if text.startswith(str(home) + '/') else text


def render(paths):
    template = (paths.core_source / 'fragments' / 'brief.md').read_text()
    values = {'repo': paths.repo, 'forge': paths.forge_home, 'claude': paths.claude_dir}
    for key, value in values.items():
        template = template.replace('{' + key + '}', _tilde(value, paths.home))
    return template
