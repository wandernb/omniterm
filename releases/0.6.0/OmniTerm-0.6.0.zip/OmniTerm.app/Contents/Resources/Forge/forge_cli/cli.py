"""`forge` command line: link, doctor, uninstall, layers, override, diff, agents-md, hooks, launchd, storage, autopilot."""
import argparse
import difflib
import json
from pathlib import Path
import shutil
import re
import sys

import adapters

from . import agents_md, attic, auto, autopilot, brief, cutover, exposure, farm, hooks, launchd, layers, linker, managed, projects, routines, state as state_mod, storage, usage, vision
from .paths import PREVIEW_NAMESPACE, Paths

HARNESSES = tuple(adapters.REGISTRY)


def _print(lines, quiet=False):
    if not quiet:
        for line in lines:
            print(line)


def link(paths, namespaces, harnesses, dry_run=False, quiet=False):
    """Relink the farm, then each harness for each namespace. Returns the report lines."""
    if not dry_run:
        # Preflight without touching disk, so a conflict leaves no trace (not even the lock file).
        link(paths, namespaces, harnesses, dry_run=True, quiet=True)
    report = []
    with state_mod.locked(paths.state_dir, enabled=not dry_run):
        current = state_mod.load(paths.state_file)
        try:
            report += linker.apply(farm.ops(paths), farm.GROUP, current, dry_run)
            resolved = farm.resolved(paths)
            for namespace in namespaces:
                for harness in harnesses:
                    ops = adapters.REGISTRY[harness].ops(paths, namespace, resolved)
                    report += linker.apply(ops, f'{harness}:{namespace}', current, dry_run)
                if not dry_run:
                    current['namespaces'][namespace] = sorted(set(current['namespaces'].get(namespace, [])) | set(harnesses))
        finally:
            # Save even on a mid-run failure, so every path already written stays owned.
            if not dry_run:
                state_mod.save(paths.state_file, current)
    _print(report or ['already linked'], quiet)
    return report


_DEPRECATED = re.compile(r'^(#[^\n]*\bdeprecated\b|\*\*deprecated\b)', re.IGNORECASE | re.MULTILINE)


def _deprecated_served(paths):
    """Served commands whose own title or a leading bold line says they are deprecated: they belong in the attic."""
    found = set()
    for root in (paths.core, paths.user):
        for path in sorted((root / 'commands').glob('*.md')) if (root / 'commands').is_dir() else ():
            if _DEPRECATED.search(path.read_text(errors='replace')):
                found.add(path.stem)
    return sorted(found)


def doctor(paths):
    """Problems (unhealthy) and notes (informational) for the current install."""
    problems, notes = [], []
    current = state_mod.load(paths.state_file)
    if not current['entries']:
        return ['not installed: run `forge link`'], notes
    if not (paths.core / 'commands').is_dir():
        problems.append(f'core does not resolve: {paths.core}')
    problems += linker.check(current)
    problems += managed.check(paths, current)
    resolved = farm.resolved(paths)
    groups = {farm.GROUP: farm.ops(paths)}
    for namespace, harnesses in current['namespaces'].items():
        for harness in harnesses:
            groups[f'{harness}:{namespace}'] = adapters.REGISTRY[harness].ops(paths, namespace, resolved)
    for group, ops in groups.items():
        try:
            actions, removals = linker.plan(ops, group, current)
        except linker.ConflictError as error:
            problems += [f'conflict: {p}: {why}' for p, why in error.conflicts]
            continue
        pending = [op.path for status, op in actions if status != 'ok'] + removals
        if pending:
            problems.append(f'{group}: {len(pending)} change(s) pending, e.g. {pending[0]} (run `forge link`)')
    problems += [f'deprecated command still served: {name} (run `forge attic add {name} --why "..."`)'
                 for name in _deprecated_served(paths)]
    launchd_owned = [p for p, e in current['entries'].items() if e['group'] == launchd.GROUP]
    if launchd_owned and launchd.plist_path(paths).is_file():
        if launchd.plist_path(paths).read_text() != launchd.render(paths):
            notes.append('LaunchAgent definition is out of date (new layer dirs?): run `forge launchd install`')
    if 'codex' in {h for hs in current['namespaces'].values() for h in hs}:
        drifted = adapters.REGISTRY['codex'].drift(paths, resolved)
        if drifted:
            notes.append(f'codex agents differ from source (fixed at cutover): {", ".join(sorted(drifted))}')
    return problems, notes


def _uninstall_preview(paths):
    with state_mod.locked(paths.state_dir):
        current = state_mod.load(paths.state_file)
        report = linker.uninstall({f'{h}:{PREVIEW_NAMESPACE}' for h in HARNESSES}, current)
        current['namespaces'].pop(PREVIEW_NAMESPACE, None)
        state_mod.save(paths.state_file, current)
    return report


def _relink_preview(paths):
    return link(paths, [PREVIEW_NAMESPACE], list(HARNESSES), quiet=True)


def cmd_link(args, paths):
    harnesses = args.harness or list(HARNESSES)
    linked = state_mod.load(paths.state_file)['namespaces']
    if args.takeover:
        if args.namespace not in ([], [cutover.NAMESPACE]):
            print('Error: --takeover only applies to the `forge` namespace.', file=sys.stderr)
            return 2
        resolved = farm.resolved(paths)
        ops = [op for h in harnesses for op in adapters.REGISTRY[h].ops(paths, cutover.NAMESPACE, resolved)]
        preview = (lambda: _uninstall_preview(paths), lambda: _relink_preview(paths))
        _print(cutover.takeover(paths, link, ops, harnesses, args.dry_run, preview=preview))
        return 0
    if cutover.NAMESPACE in args.namespace and cutover.NAMESPACE not in linked:
        print('Error: the live `forge` namespace is taken over with `forge link --takeover` (backs up first).', file=sys.stderr)
        return 2
    namespaces = args.namespace or sorted(linked) or [PREVIEW_NAMESPACE]
    link(paths, namespaces, harnesses, args.dry_run)
    return 0


def cmd_backup(args, paths):
    if args.list:
        for found in cutover.backups(paths):
            print(found)
        return 0
    entries = {p: 'takeover' for p in cutover.takeover_paths(paths)}
    entries.update({c: 'config' for c in cutover.config_paths(paths)})
    print(cutover.backup(paths, 'manual', entries))
    return 0


def cmd_rollback(args, paths):
    _print(cutover.rollback(paths, args.backup, config=args.config, relink=lambda: _relink_preview(paths)))
    return 0


def cmd_cleanup(args, paths):
    _print(cutover.cleanup(paths, lambda: _uninstall_preview(paths), dry_run=not args.apply))
    tracked = cutover.tracked_forge_paths(paths)
    if tracked:
        print(f'\nThen commit in {paths.claude_dir} (forge now serves these as links):')
        print(f'  git -C {paths.claude_dir} rm -r --cached --quiet -- ' + ' '.join(cutover.git_rm_specs(tracked)))
        print(f'  git -C {paths.claude_dir} add -A .gitignore skills')
        print(f'  git -C {paths.claude_dir} commit -m "Serve forge from ~/.forge (standalone repo)"')
    if not args.apply:
        print('(dry run — re-run with --apply; a backup is kept)')
    return 0


def cmd_doctor(args, paths):
    problems, notes = doctor(paths)
    if problems and args.repair:
        current = state_mod.load(paths.state_file)
        if current['namespaces']:
            for namespace, harnesses in sorted(current['namespaces'].items()):
                link(paths, [namespace], harnesses, quiet=args.hook)
        _print(managed.repair(paths, current), quiet=args.hook)
        problems, notes = doctor(paths)
    if args.hook:
        # SessionStart hooks: silent when healthy, one line otherwise, never fail the session.
        if problems:
            print(f'forge doctor: {len(problems)} problem(s): {problems[0]} — run `forge doctor`')
        return 0
    _print([f'✗ {p}' for p in problems] + [f'· {n}' for n in notes])
    if not problems:
        print('✓ forge install healthy')
    return 1 if problems else 0


def cmd_session_start(args, paths):
    """SessionStart hook: print the brief and, if unhealthy, one health line. Never fails a session.

    Each stage fails on its own (a broken install must not break the harness session): a crashing
    health check keeps the brief and exposure line and says so in one line. A crashing exposure
    lookup says protected, because an error must never make a project look freer."""
    projects.session_hook(paths)
    try:
        text = brief.render(paths)
        try:
            line = exposure.line(paths)
        except Exception as error:  # noqa: BLE001
            line = f'- **Exposure**: protected (exposure check crashed: {_one_line(error)}). (Momentum M14)\n'
        try:
            problems, _ = doctor(paths)
            if problems:
                line += f'forge doctor: {len(problems)} problem(s): {problems[0]} — run `forge doctor --repair`\n'
        except Exception as error:  # noqa: BLE001
            line += f'forge health check crashed: {_one_line(error)}\n'
        text = text[:-4] + line + '---\n' if text.endswith('\n---\n') else text + line
        print(text, end='')
    except Exception:  # noqa: BLE001
        pass
    return 0


def _one_line(error, limit=200):
    """`Type: message` on one line, capped so a crash cannot flood the brief."""
    try:
        message = ' '.join(str(error).split())
    except Exception:  # noqa: BLE001 - an exception whose __str__ raises
        message = '(unprintable)'
    text = f'{type(error).__name__}: {message}'
    return text if len(text) <= limit else text[:limit - 1] + '…'


def cmd_projects(args, paths):
    return projects.run(args, paths)


def cmd_exposure(args, paths):
    tier, guard, _ = exposure.lookup(paths, args.path)
    print(f'{tier}: {guard}' if guard else tier)
    return 0


def cmd_uninstall(args, paths):
    with state_mod.locked(paths.state_dir, enabled=not args.dry_run):
        current = state_mod.load(paths.state_file)
        if args.all:
            groups = {e['group'] for e in current['entries'].values()}
            if launchd.GROUP in groups and not args.dry_run:
                print('\n'.join(launchd.uninstall(paths, current)))
        else:
            namespaces = args.namespace or [PREVIEW_NAMESPACE]
            groups = {f'{h}:{ns}' for ns in namespaces for h in HARNESSES}
        report = linker.uninstall(groups, current, args.dry_run)
        if not args.dry_run:
            for namespace in list(current['namespaces']):
                if args.all or namespace in (args.namespace or [PREVIEW_NAMESPACE]):
                    del current['namespaces'][namespace]
            state_mod.save(paths.state_file, current)
    _print(report or ['nothing to remove'])
    return 0


def _find(paths, name):
    """Resolve `next`, `commands/next` or `agents/forge-scout.md` to a farm-relative path."""
    resolved = farm.resolved(paths)
    candidates = [name, f'{name}.md', f'commands/{name}.md', f'agents/{name}.md']
    for candidate in candidates:
        if candidate in resolved:
            return candidate, resolved[candidate]
    raise SystemExit(f'Error: no forge file named {name!r}')


def cmd_layers(args, paths):
    for rel, layer, shadows in layers.describe(paths.core_source, paths.user, args.name):
        print(f'{layer:4}  {rel}{"  (shadows core)" if shadows else ""}')
    return 0


def cmd_override(args, paths):
    rel, layer = _find(paths, args.name)
    dest = paths.user / rel
    if layer == layers.USER or dest.exists():
        print(f'Error: {rel} is already in the user layer: {dest}', file=sys.stderr)
        return 1
    print(f'{"Would copy" if args.dry_run else "Copied"} core/{rel} -> {dest}')
    if not args.dry_run:
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(paths.core_source / rel, dest)
        link(paths, sorted(state_mod.load(paths.state_file)['namespaces']) or [PREVIEW_NAMESPACE], list(HARNESSES), quiet=True)
    return 0


def cmd_diff(args, paths):
    rel, _ = _find(paths, args.name)
    core_file, user_file = paths.core_source / rel, paths.user / rel
    if not (core_file.is_file() and user_file.is_file()):
        print(f'{rel}: only in {"user" if user_file.is_file() else "core"} layer')
        return 0
    diff = difflib.unified_diff(core_file.read_text().splitlines(True), user_file.read_text().splitlines(True),
                                f'core/{rel}', f'user/{rel}')
    sys.stdout.writelines(diff)
    return 0


def cmd_agents_md(args, paths):
    target = args.target or paths.claude_dir / 'AGENTS.md'
    changed, diff = agents_md.apply(target, managed.fragment(paths), dry_run=not args.apply,
                                    backup_dir=paths.state_dir / 'backups', remove=args.remove)
    sys.stdout.writelines(diff)
    if args.apply:
        with state_mod.locked(paths.state_dir):
            current = state_mod.load(paths.state_file)
            if args.remove:
                managed.forget_agents_md(current)
            else:
                managed.record_agents_md(current, target)
            state_mod.save(paths.state_file, current)
    if not changed:
        print(f'{target}: forge block up to date')
    elif not args.apply:
        print(f'(dry run — re-run with --apply to write {target}; a backup is kept)')
    return 0


def cmd_hooks(args, paths):
    action = hooks.uninstall if args.remove else hooks.install
    harnesses = args.harness or list(HARNESSES)
    if args.apply:
        with state_mod.locked(paths.state_dir):
            current = state_mod.load(paths.state_file)
            managed.record_hooks(current, harnesses, remove=args.remove)
            state_mod.save(paths.state_file, current)
    for harness in harnesses:
        path, changed = action(paths, harness, dry_run=not args.apply)
        verb = ('would update' if not args.apply else 'updated') if changed else 'unchanged'
        print(f'{verb}: {path} ({harness} SessionStart: {hooks.command(paths)}; Stop: {hooks.command(paths, "Stop")})')
    if args.apply and 'codex' in (args.harness or HARNESSES) and not args.remove:
        print('Codex: run /hooks once in Codex to trust the new hook.')
    if not args.apply:
        print('(dry run — re-run with --apply; a backup is kept)')
    return 0


def cmd_routines(args, paths):
    repos = routines.load_config(paths)
    if args.repo and args.repo not in repos:
        raise ValueError(f'unknown routines repo {args.repo}; known: {", ".join(sorted(repos))}')
    if args.action == 'show':
        selected = repos[args.repo] if args.repo else repos
        print(json.dumps(selected, indent=2))
        return 0
    names = [args.repo] if args.repo else sorted(repos)
    if args.action == 'security':
        reports = [routines.security(name, repos[name]) for name in names]
        print(json.dumps(reports, indent=2) if args.json
              else '\n'.join(routines.render_security(report) for report in reports))
        return 0
    rows = []
    for name in names:
        rows += routines.sweep(name, repos[name], apply=args.apply)
    print(routines.render(rows))
    return 0


def cmd_storage(args, paths):
    action = args.action or 'report'
    if action == 'stop-hook':
        return storage.stop_hook(paths)
    if action == 'free':
        print(storage.free_line(storage.disk(paths.home)))
        return 0
    if action == 'add':
        row = storage.add(paths, args.path, args.why, kind=args.kind, until=args.until,
                          project=args.project, session=args.session)
        print(f'ledgered: {row["Path"]}  {row["Size"]}  {row["Kind"]}  keep until {row["Keep until"]}')
        return 0
    if action == 'done':
        for row in storage.done(paths, args.path, keep=args.keep):
            print(f'{row["Path"]}: {row["Status"]}')
        return 0
    if action == 'ledger':
        rows, findings = storage.ledger_findings(paths)
        flagged = {f['Path']: f for f in findings}
        shown = [r for r in rows if not args.open or r['Path'] in flagged or r['Status'] == 'present']
        for row in shown:
            note = f'  ⚑ {flagged[row["Path"]]["state"]}: {flagged[row["Path"]]["reason"]}' if row['Path'] in flagged else ''
            print(f'{row["Created"]}  {row["Size"]:>9}  {row["Kind"]:<8} {row["Path"]}  [{row["Status"]}]{note}')
        print(f'{len(rows)} row(s), {len(findings)} need action — {storage.ledger_path(paths)}')
        return 1 if findings and args.check else 0
    result = storage.report(paths, roots=args.root or None, min_size=storage.parse_size(args.min_size),
                            idle_days=args.idle_days, projects=not args.quick, docker=not args.no_docker)
    print(storage.to_json(result) if args.json else storage.render(result, paths.home, top=args.top))
    return 0


def cmd_usage(args, paths):
    if args.tokens:
        rows = usage.tokens_report(paths, days=args.days or usage.TOKEN_DAYS)
        lines = usage.render_tokens(rows)
    elif args.prompts:
        rows = usage.prompt_clusters(paths, days=args.days or 60, min_sessions=args.min_sessions, limit=args.limit)
        lines = usage.render_clusters(rows)
    else:
        rows = usage.commands_report(paths, days=args.days or usage.DEFAULT_DAYS, transcripts=not args.no_transcripts)
        lines = usage.render_commands(rows)
    print(json.dumps(rows, indent=1)) if args.json else _print(lines)
    return 0


def _relink_live(paths):
    """Relink what is already linked, after a user-layer change; a fresh sandbox has nothing to relink."""
    linked = state_mod.load(paths.state_file)['namespaces']
    if linked:
        link(paths, sorted(linked), list(HARNESSES), quiet=True)


def cmd_attic(args, paths):
    if args.action == 'list':
        _print(attic.listing(paths, args.core_root))
        return 0
    if not args.name:
        print('Error: a command name is required.', file=sys.stderr)
        return 2
    if args.action == 'add':
        report, relink = attic.add(paths, args.name, args.why or '', args.core_root, args.dry_run)
    else:
        report, relink = attic.restore(paths, args.name, args.core_root, args.dry_run)
    if relink:
        auto.write_catalog(paths)
        _relink_live(paths)
    _print(report)
    return 0


def cmd_auto(args, paths):
    if args.action == 'quota':
        reason = auto.quota(paths)
        print(reason or 'room for one more')
        return 1 if reason else 0
    if args.action == 'catalog':
        changed = auto.write_catalog(paths, args.dry_run)
        print(('would rewrite' if args.dry_run else 'rewrote') + f' {paths.user / auto.CATALOG}' if changed else 'catalog is current')
        if changed and not args.dry_run:
            _relink_live(paths)
        return 0
    found = auto.problems(paths)
    _print(found or ['generated commands are healthy'])
    return 1 if found else 0


def cmd_vision(args, paths):
    if args.action == 'blind':
        result = vision.blind(paths)
    elif args.action == 'clean':
        vision.clean(args.target)
        result = {'removed': args.target}
    elif args.action == 'status':
        result = vision.status()
        result['dreams'] = vision.pending_dreams(paths, result['repo'])
    elif args.action == 'reconciled':
        result = {'moved': vision.retire_dream(paths, vision.repo_name(vision.repo_root()), args.target)}
    elif args.action == 'save':
        result = {'result': vision.save(None, args.message or 'Reconcile the vision with a new dream', args.dry_run)}
    else:
        result = vision.land(paths, args.branch, args.worktree, dry_run=args.dry_run)
    print(json.dumps(result, indent=1))
    return 0


def cmd_autopilot(args, paths):
    root = Path(args.repo).resolve() if args.repo else vision.repo_root()
    name = vision.repo_name(root)
    interval = autopilot.parse_interval(args.interval)
    if args.action == 'run':
        result = autopilot.run(paths, root, args.harness, interval, args.focus, once=args.once, dry_run=args.dry_run)
    elif args.action == 'start':
        if args.dry_run:
            result = autopilot.run(paths, root, args.harness, interval, args.focus, dry_run=True)
        else:
            result = autopilot.start(paths, root, args.harness, interval, args.focus)
    elif args.action == 'stop':
        result = {'repo': name, 'dry_run': True} if args.dry_run else autopilot.stop(paths, name)
    else:
        result = autopilot.status(paths, name)
    print(json.dumps(result, indent=1))
    return 0


def cmd_launchd(args, paths):
    with state_mod.locked(paths.state_dir, enabled=not args.dry_run):
        current = state_mod.load(paths.state_file)
        if args.action == 'print':
            print(launchd.render(paths), end='')
            return 0
        action = launchd.install if args.action == 'install' else launchd.uninstall
        try:
            report = action(paths, current, args.dry_run)
        finally:
            # Record what was written even if launchctl failed, so uninstall can still remove it.
            if not args.dry_run:
                state_mod.save(paths.state_file, current)
    _print(report or ['nothing to do'])
    return 0


def cmd_bin(args, paths):
    """Put `forge` on PATH as a recorded symlink (removed by `forge uninstall --all`)."""
    with state_mod.locked(paths.state_dir, enabled=not args.dry_run):
        current = state_mod.load(paths.state_file)
        ops = [linker.symlink(args.dir / 'forge', paths.repo / 'bin' / 'forge')]
        if args.action == 'install':
            report = linker.apply(ops, 'bin', current, args.dry_run)
        else:
            report = linker.uninstall({'bin'}, current, args.dry_run)
        if not args.dry_run:
            state_mod.save(paths.state_file, current)
    _print(report or ['already installed'])
    return 0


def parser():
    root = argparse.ArgumentParser(prog='forge', description=__doc__)
    sub = root.add_subparsers(dest='command', required=True)

    p = sub.add_parser('link', help='resolve layers into ~/.forge and link harnesses')
    p.add_argument('--namespace', action='append', default=[], help=f'command namespace (default: recorded, else {PREVIEW_NAMESPACE})')
    p.add_argument('--harness', action='append', choices=HARNESSES, help='limit to a harness (repeatable)')
    p.add_argument('--takeover', action='store_true', help='cutover: back up and replace the live `forge` suite')
    p.add_argument('--dry-run', action='store_true')
    p.set_defaults(func=cmd_link)

    p = sub.add_parser('doctor', help='check every owned link and file')
    p.add_argument('--repair', action='store_true', help='relink recorded namespaces when unhealthy')
    p.add_argument('--hook', action='store_true', help='SessionStart mode: silent when healthy, always exit 0')
    p.set_defaults(func=cmd_doctor)

    p = sub.add_parser('session-start', help='SessionStart hook: print the session brief (+ health line)')
    p.set_defaults(func=cmd_session_start)

    p = sub.add_parser('exposure', help="print a project's exposure tier and guard (Momentum M14)")
    p.add_argument('path', nargs='?', help='project path (default: the working directory)')
    p.set_defaults(func=cmd_exposure)

    p = sub.add_parser('projects', help='forge projects on this machine: list, resolve a path, show one, register (JSON with --json)')
    p.add_argument('action', nargs='?', choices=['list', 'resolve', 'show', 'file', 'files', 'add', 'remove'], default='list')
    p.add_argument('path', nargs='?', help='a path inside the project (default: the working directory)')
    p.add_argument('file', nargs='?', help='file/files: path relative to the main checkout')
    p.add_argument('--json', action='store_true', help='machine-readable output with a schema number')
    p.add_argument('--all', action='store_true', help='list: also repositories without a knowledge/ folder')
    p.add_argument('--stdin', action='store_true', help='resolve: one path per line on stdin, {path: root} out')
    p.set_defaults(func=cmd_projects)

    p = sub.add_parser('uninstall', help='remove exactly what forge recorded')
    p.add_argument('--namespace', action='append', default=[])
    p.add_argument('--all', action='store_true', help='also remove the farm and every other owned path')
    p.add_argument('--dry-run', action='store_true')
    p.set_defaults(func=cmd_uninstall)

    p = sub.add_parser('layers', help='show which layer serves each file')
    p.add_argument('name', nargs='?')
    p.set_defaults(func=cmd_layers)

    p = sub.add_parser('override', help='copy a core file into the user layer for editing')
    p.add_argument('name')
    p.add_argument('--dry-run', action='store_true')
    p.set_defaults(func=cmd_override)

    p = sub.add_parser('diff', help='diff a user shadow against its core file')
    p.add_argument('name')
    p.set_defaults(func=cmd_diff)

    p = sub.add_parser('agents-md', help='render the forge block into a global AGENTS.md (dry run unless --apply)')
    p.add_argument('--target', type=Path, help='file to render into (default: <claude>/AGENTS.md)')
    p.add_argument('--remove', action='store_true', help='drop the block and stop maintaining it')
    p.add_argument('--apply', action='store_true')
    p.set_defaults(func=cmd_agents_md)

    p = sub.add_parser('hooks', help='add/remove the SessionStart brief + Stop storage hooks (dry run unless --apply)')
    p.add_argument('--harness', action='append', choices=HARNESSES)
    p.add_argument('--remove', action='store_true')
    p.add_argument('--apply', action='store_true')
    p.set_defaults(func=cmd_hooks)

    p = sub.add_parser('backup', help='tar every live forge path + global config files')
    p.add_argument('--list', action='store_true', help='list existing backups')
    p.set_defaults(func=cmd_backup)

    p = sub.add_parser('rollback', help='undo the takeover from its backup')
    p.add_argument('--backup', type=Path, help='backup dir (default: the latest takeover backup)')
    p.add_argument('--config', action='store_true', help='also restore AGENTS.md, settings.json, hooks.json')
    p.set_defaults(func=cmd_rollback)

    p = sub.add_parser('cleanup', help='after a verified takeover: drop the preview, retire old generators (dry run unless --apply)')
    p.add_argument('--apply', action='store_true')
    p.set_defaults(func=cmd_cleanup)

    p = sub.add_parser('bin', help='link the forge CLI into a PATH directory')
    p.add_argument('action', choices=['install', 'uninstall'])
    p.add_argument('--dir', type=Path, default=Path('/usr/local/bin'))
    p.add_argument('--dry-run', action='store_true')
    p.set_defaults(func=cmd_bin)

    p = sub.add_parser('storage', help='storage hygiene: report reclaimable space, keep the heavy-item ledger (read-only)')
    p.add_argument('action', nargs='?', choices=['report', 'free', 'ledger', 'add', 'done', 'stop-hook'],
                   help='report (default) | free (one line: available space) | ledger | add <path> | done <path> | stop-hook (Stop hook entry)')
    p.add_argument('path', nargs='?', help='item path for add/done')
    p.add_argument('--root', action='append', help='project root to scan (repeatable; default: storage.json roots, else ~/Projects)')
    p.add_argument('--min-size', default='200M', help='smallest item to report (default 200M)')
    p.add_argument('--idle-days', type=int, default=14, help='a project untouched this long has deletable build/deps (default 14)')
    p.add_argument('--top', type=int, default=25)
    p.add_argument('--quick', action='store_true', help='skip the project scan (caches, VMs, Docker, ledger only)')
    p.add_argument('--no-docker', action='store_true')
    p.add_argument('--json', action='store_true')
    p.add_argument('--why', default='', help='add: what it is and why it is kept')
    p.add_argument('--kind', default='other', choices=storage.KINDS)
    p.add_argument('--until', default='end of session', help='add: end of session | YYYY-MM-DD | a condition | permanent: reason')
    p.add_argument('--project', help='add: project label (default: git root name of the cwd)')
    p.add_argument('--session', help='add: session label (task or session id)')
    p.add_argument('--keep', help='done: keep the item, with this reason, instead of marking it removed')
    p.add_argument('--open', action='store_true', help='ledger: only present or flagged rows')
    p.add_argument('--check', action='store_true', help='ledger: exit 1 when any row needs action')
    p.set_defaults(func=cmd_storage)

    p = sub.add_parser('routines', help='maintenance routines: show repo policy, sweep PRs through the merge gate, summarize security alerts')
    p.add_argument('action', choices=['show', 'sweep', 'security'])
    p.add_argument('--repo', help='one repo from routines.json (default: all)')
    p.add_argument('--apply', action='store_true', help='sweep: merge or update for real (default: dry run)')
    p.add_argument('--json', action='store_true', help='security: machine-readable output')
    p.set_defaults(func=cmd_routines)

    p = sub.add_parser('usage', help='evidence from Claude and Codex transcripts: command use, or repeated prompts with --prompts (read-only)')
    p.add_argument('--prompts', action='store_true', help='cluster repeated typed prompts instead of reporting command use')
    p.add_argument('--tokens', action='store_true',
                   help='Claude tokens per kind of session (scheduled, interactive) and per scheduled command, '
                        'each message counted once')
    p.add_argument('--days', type=int, help='window in days (default: 90 for commands, 60 for --prompts, 7 for --tokens)')
    p.add_argument('--min-sessions', type=int, default=4, help='--prompts: smallest cluster to report')
    p.add_argument('--limit', type=int, default=40, help='--prompts: most clusters to report')
    p.add_argument('--no-transcripts', action='store_true', help='histories only: skip the Skill calls in Claude transcripts')
    p.add_argument('--json', action='store_true')
    p.set_defaults(func=cmd_usage)

    p = sub.add_parser('attic', help='retire a command to its layer\'s .attic, or bring one back')
    p.add_argument('action', choices=['list', 'add', 'restore'])
    p.add_argument('name', nargs='?', help='command name, `auto:<name>` for a generated one')
    p.add_argument('--why', help='add: the reason, recorded in the attic index')
    p.add_argument('--core-root', help='a worktree\'s core/: required for anything in core, never the live tree')
    p.add_argument('--dry-run', action='store_true')
    p.set_defaults(func=cmd_attic)

    p = sub.add_parser('auto', help='guard rails for generated commands: check, quota, catalog')
    p.add_argument('action', choices=['check', 'quota', 'catalog'])
    p.add_argument('--dry-run', action='store_true', help='catalog: write nothing')
    p.set_defaults(func=cmd_auto)

    p = sub.add_parser('vision', help='dream and vision mechanics: blind copy, status, save, and the gate that lands a step')
    p.add_argument('action', choices=['blind', 'clean', 'status', 'reconciled', 'save', 'land'])
    p.add_argument('target', nargs='?', help='clean: the blind copy; reconciled: the dream file')
    p.add_argument('--message', '-m', help='save: the commit message')
    p.add_argument('--branch', help='land: the forge/advance/ branch')
    p.add_argument('--worktree', help="land: that branch's worktree, where verify runs")
    p.add_argument('--dry-run', action='store_true')
    p.set_defaults(func=cmd_vision)

    p = sub.add_parser('autopilot', help='run /forge:autopilot ticks as fresh codex/claude processes, outside any session')
    p.add_argument('action', choices=['run', 'start', 'stop', 'status'],
                   help='run: loop in the foreground; start: detached; stop: end the runner; status: read-only')
    p.add_argument('--harness', choices=autopilot.HARNESSES, default='codex')
    p.add_argument('--interval', help='20m, 1h, 300s; omitted = self-paced by the tick')
    p.add_argument('--focus', help='free text the ticks prefer')
    p.add_argument('--repo', help='checkout to drive (default: the current git top-level)')
    p.add_argument('--once', action='store_true', help='run: one tick, then exit')
    p.add_argument('--dry-run', action='store_true', help='print the tick command; run nothing')
    p.set_defaults(func=cmd_autopilot)

    p = sub.add_parser('launchd', help='manage the keep-alive LaunchAgent')
    p.add_argument('action', choices=['install', 'uninstall', 'print'])
    p.add_argument('--dry-run', action='store_true')
    p.set_defaults(func=cmd_launchd)
    return root


def main(argv=None, env=None):
    args = parser().parse_args(argv)
    paths = Paths.from_env(env)
    try:
        return args.func(args, paths)
    except (linker.ConflictError, ValueError, OSError) as error:
        print(f'Error: {error}', file=sys.stderr)
        return 1
