"""Layer resolution: a user file shadows the core file at the same relative path.

Project-level overrides (`./knowledge/commands/<name>.md`) are read by the commands themselves in
their Phase 0 and are not resolved here.
"""
from pathlib import Path

# Kinds exposed in the farm. `templates`/`fragments` are core-only; `extensions` is user-only. A layer's
# `.attic/` holds retired files: it is not a kind, so nothing in it is ever served.
KINDS = ('commands', 'agents', 'knowledge', 'extensions', 'templates', 'fragments', 'skills')
IGNORED_NAMES = {'.DS_Store', '__pycache__', '.git', '.gitkeep', '.pytest_cache'}
IGNORED_SUFFIXES = ('.pyc',)

CORE = 'core'
USER = 'user'


def _files(root):
    """Relative POSIX paths of every file under root's kind directories."""
    found = []
    for kind in KINDS:
        base = root / kind
        if not base.is_dir():
            continue
        for path in sorted(base.rglob('*')):
            rel = path.relative_to(root)
            if any(part in IGNORED_NAMES for part in rel.parts) or path.name.endswith(IGNORED_SUFFIXES):
                continue
            if path.is_file():
                found.append(rel.as_posix())
    return found


def resolve(core_dir, user_dir=None):
    """Map each relative path to the layer that serves it: {'commands/next.md': 'core', ...}."""
    resolved = {rel: CORE for rel in _files(Path(core_dir))}
    if user_dir is not None and Path(user_dir).is_dir():
        for rel in _files(Path(user_dir)):
            resolved[rel] = USER
    return dict(sorted(resolved.items()))


def describe(core_dir, user_dir, name=None):
    """Rows of (relpath, layer, shadows_core) for `forge layers`, optionally filtered by name."""
    core_files = set(_files(Path(core_dir)))
    rows = []
    for rel, layer in resolve(core_dir, user_dir).items():
        if name and Path(rel).stem != name and rel != name:
            continue
        rows.append((rel, layer, layer == USER and rel in core_files))
    return rows
