"""Render the forge fragment into a marked, managed block of a global AGENTS.md.

Text outside the markers is never touched; rendering twice is a no-op; every write keeps a backup.
"""
import difflib

from . import backups

BEGIN = '<!-- forge:begin (managed by `forge agents-md`; edit core/fragments/AGENTS.forge.md) -->'
END = '<!-- forge:end -->'
BEGIN_PREFIX = '<!-- forge:begin'


def block(fragment):
    return f'{BEGIN}\n{fragment.strip()}\n{END}\n'


def render(text, fragment):
    """Return text with the managed block replaced, or appended if absent."""
    start = text.find(BEGIN_PREFIX)
    if start == -1:
        if not text or text.endswith('\n\n'):
            separator = ''
        else:
            separator = '\n' if text.endswith('\n') else '\n\n'
        return text + separator + block(fragment)
    end = text.find(END, start)
    if end == -1:
        raise ValueError('forge:begin marker without forge:end; fix the file by hand')
    end += len(END)
    if text[end:end + 1] == '\n':
        end += 1
    return text[:start] + block(fragment) + text[end:]


def strip(text):
    """Return text without the managed block (and the blank line that separated it)."""
    start = text.find(BEGIN_PREFIX)
    if start == -1:
        return text
    end = text.find(END, start)
    if end == -1:
        raise ValueError('forge:begin marker without forge:end; fix the file by hand')
    end += len(END)
    if text[end:end + 1] == '\n':
        end += 1
    head = text[:start]
    if head.endswith('\n\n'):
        head = head[:-1]
    return head + text[end:]


def apply(target, fragment, dry_run=False, backup_dir=None, remove=False):
    """(changed, diff_lines). Writes atomically with a timestamped backup unless dry_run."""
    target = target.resolve() if target.is_symlink() else target
    before = target.read_text() if target.exists() else ''
    after = strip(before) if remove else render(before, fragment)
    diff = list(difflib.unified_diff(before.splitlines(True), after.splitlines(True), str(target), str(target)))
    if before == after or dry_run:
        return before != after, diff
    if target.exists():
        backups.keep(target, backup_dir or target.parent)
    tmp = target.with_name(f'.{target.name}.forge-tmp')
    tmp.write_text(after)
    tmp.replace(target)
    return True, diff
