"""Evidence for the self-tending commands: what is actually used, and what the user keeps asking for.

Read-only. Typed prompts come from the two harness histories, which hold only what a human typed; Claude
transcripts add the Skill tool calls a model made. Scheduled runs are separated out, so a daily agent
cannot make a command look popular or make its own prompt look like a habit. Unreadable lines are skipped:
a history file is someone else's append-only log and this never repairs it.
"""
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import time

from . import farm

DAY = 86400
DEFAULT_DAYS = 90
GRACE_DAYS = 30
TOKEN_DAYS = 7
TOKEN_FIELDS = ('input_tokens', 'output_tokens', 'cache_creation_input_tokens', 'cache_read_input_tokens')

COMMAND_REFS = re.compile(r'(?:^|[\s(`"\'])/forge:([a-z0-9][a-z0-9:-]*)')
CODEX_REFS = re.compile(r'(?:^|[\s(\[`"\'])\$forge-([a-z0-9][a-z0-9-]*)')
SKILL_CALL = re.compile(rb'"name":"Skill","input":\{[^{}]*?"skill":"forge:([a-z0-9:-]+)"')
SESSION_ID = re.compile(rb'"sessionId":\s*"([^"]+)"')

STOPWORDS = frozenset('''
a about all also am an and any are as at be been but by can could do does for from get go going got had has
have here how i if in into is it its just let like make me more my need no not now of on one only or our out
please should so some still that the their them then there these they this to too up us use want was we were
what when where which will with would you your
'''.split())
SECRET = re.compile(
    r'(?i)\b(?:sk|ghp|gho|xox[abp]|whsec|glpat|pk|rk)[-_][a-z0-9_-]{10,}'
    r'|\b[a-f0-9]{32,}\b'
    r'|\b[a-z0-9+_]{40,}={0,2}'
    r'|\b[\w.+-]+@[\w-]+\.[\w.-]+\b'
    r'|\b(?:password|passwd|secret|token|api[_-]?key)\b\s*[:=]\s*\S+'
)
PASTE_MARKER = re.compile(r'\[(?:Pasted|Image)[^\]]*\]|\[\$[\w-]+\]\([^)]*\)', re.I)


@dataclass(frozen=True)
class Prompt:
    harness: str
    ts: float
    session: str
    project: str
    text: str


def scrub(text):
    """Redact secret-shaped tokens and addresses from anything that leaves a transcript."""
    return SECRET.sub('[redacted]', text)


def _lines(path):
    try:
        with open(path, errors='replace') as handle:
            for line in handle:
                try:
                    yield json.loads(line)
                except ValueError:
                    continue
    except OSError:
        return


def prompts(paths):
    """Every typed prompt from both harnesses, oldest first within each."""
    for entry in _lines(paths.claude_dir / 'history.jsonl'):
        text, stamp = entry.get('display'), entry.get('timestamp')
        if isinstance(text, str) and isinstance(stamp, (int, float)):
            yield Prompt('claude', stamp / 1000, str(entry.get('sessionId', '')), str(entry.get('project', '')), text)
    for entry in _lines(paths.codex_dir / 'history.jsonl'):
        text, stamp = entry.get('text'), entry.get('ts')
        if isinstance(text, str) and isinstance(stamp, (int, float)):
            yield Prompt('codex', float(stamp), str(entry.get('session_id', '')), '', text)


def scheduled_prompts(paths):
    """Startup prompts of the Omni agents. Only that field is read from each definition."""
    found = set()
    for path in sorted((paths.home / '.omni' / 'agents').glob('*.json')):
        try:
            prompt = json.loads(path.read_text()).get('startup_prompt')
        except (OSError, ValueError, AttributeError):
            continue
        if isinstance(prompt, str) and prompt.strip():
            found.add(prompt.strip())
    return found


def opening_prompts(all_prompts):
    """{session: the text of its first prompt}. Prompts without a session are left out."""
    opening = {}
    for prompt in all_prompts:
        if prompt.session and prompt.ts < opening.get(prompt.session, (float('inf'),))[0]:
            opening[prompt.session] = (prompt.ts, prompt.text)
    return {session: text for session, (_, text) in opening.items()}


def scheduled_runs(all_prompts, scheduled):
    """{session: opening prompt} for sessions that open with a scheduled prompt: a scheduled run starts with its
    agent's prompt, and a person who later types that same command in their own session is not one."""
    return {session: text for session, text in opening_prompts(all_prompts).items() if is_scheduled(text, scheduled)}


def scheduled_sessions(all_prompts, scheduled):
    return set(scheduled_runs(all_prompts, scheduled))


def run_command(text):
    """What a scheduled run ran: the forge command its prompt names, else a leading `/name`, else `other`."""
    names = sorted(_names(text))
    if names:
        return names[0]
    first = text.split(maxsplit=1)[0] if text.strip() else ''
    return first[1:] if first.startswith('/') and len(first) > 1 else 'other'


def is_scheduled(text, scheduled):
    stripped = text.strip()
    return stripped in scheduled or '--scheduled' in stripped


def _names(text):
    """Canonical command names in a prompt: `plan`, or `auto:x` for a generated one."""
    found = {match.rstrip(':') for match in COMMAND_REFS.findall(text)}
    for match in CODEX_REFS.findall(text):
        found.add('auto:' + match[len('auto-'):] if match.startswith('auto-') else match)
    return found


def command_files(paths):
    """{canonical name: (rel path, layer)} for every served command, top level and auto/."""
    found = {}
    for rel, layer in farm.resolved(paths).items():
        parts = Path(rel).parts
        if rel.endswith('.md') and parts[0] == 'commands':
            if len(parts) == 2:
                found[Path(rel).stem] = (rel, layer)
            elif len(parts) == 3 and parts[1] == 'auto':
                found['auto:' + Path(rel).stem] = (rel, layer)
    return found


def _layer_root(paths, layer):
    return paths.core_source if layer == 'core' else paths.user


def _reference_files(paths):
    for rel, layer in farm.resolved(paths).items():
        parts = Path(rel).parts
        prose = rel.endswith('.md')
        if prose and (parts[0] in ('commands', 'agents', 'extensions', 'fragments', 'templates', 'skills')
                      or (parts[0] == 'knowledge' and len(parts) == 2)):
            yield rel, _layer_root(paths, layer) / rel


def references(paths, names):
    """{name: sorted rel paths citing it}: slash and `$` forms, roster backticks, command paths."""
    texts = {}
    for rel, path in _reference_files(paths):
        try:
            texts[rel] = path.read_text(errors='replace')
        except OSError:
            continue
    found = {}
    for name in names:
        short = name.split(':')[-1]
        pattern = re.compile(
            rf'(?<![\w/-])(?:/forge:{re.escape(name)}|\$forge-{re.escape(name.replace(":", "-"))}'
            rf'|`{re.escape(name)}`|commands/{re.escape(name.replace(":", "/"))}\.md)(?![\w-])')
        own = {f'commands/{name.replace(":", "/")}.md', f'extensions/{short}.md'}
        found[name] = sorted(rel for rel, text in texts.items() if rel not in own and pattern.search(text))
    return found


def project_overrides(paths):
    """{name: count} of `knowledge/commands/<name>.md` files across project checkouts."""
    roots = paths.home / 'Projects'
    counts = Counter()
    for pattern in ('*', '*/*', '*/*/*', '*/@head', '*/*/@head', '*/*/*/@head'):
        for path in roots.glob(f'{pattern}/knowledge/commands/*.md'):
            counts[path.stem] += 1
    return counts


def skill_calls(paths, since, skip_sessions=()):
    """Model-made Skill calls per command from Claude transcripts newer than `since`.

    Returns {name: (count, newest file mtime)}. Sessions in `skip_sessions` were scheduled runs; a line is
    attributed to the `sessionId` it carries, as `token_usage` does, so a scheduled run's subagent transcripts
    (`<session>/subagents/agent-*.jsonl`) are skipped with it.
    """
    calls, latest = Counter(), {}
    for path in (paths.claude_dir / 'projects').rglob('*.jsonl'):
        try:
            mtime = path.stat().st_mtime
        except OSError:
            continue
        if mtime < since or path.stem in skip_sessions:
            continue
        try:
            with open(path, 'rb') as handle:
                for line in handle:
                    if b'"name":"Skill"' not in line:
                        continue
                    session = SESSION_ID.search(line)
                    if session and session.group(1).decode() in skip_sessions:
                        continue
                    for raw in SKILL_CALL.findall(line):
                        name = raw.decode()
                        calls[name] += 1
                        latest[name] = max(latest.get(name, 0), mtime)
        except OSError:
            continue
    return {name: (count, latest[name]) for name, count in calls.items()}


def added_dates(paths):
    """{rel path: YYYY-MM-DD} of when git first saw each command, for both layers."""
    found = {}
    for root, prefix in ((paths.repo, 'core/'), (paths.user, '')):
        try:
            log = subprocess.run(
                ['git', '-C', str(root), 'log', '--diff-filter=A', '--format=@%as', '--name-only', '--', f'{prefix}commands'],
                capture_output=True, text=True, timeout=30, check=False).stdout
        except (OSError, subprocess.SubprocessError):
            continue
        stamp = None
        for line in log.splitlines():
            if line.startswith('@'):
                stamp = line[1:]
            elif line.strip():
                found[line.strip()[len(prefix):]] = stamp  # oldest commit is listed last, so it wins
    return found


def _iso(ts):
    return datetime.fromtimestamp(ts, timezone.utc).strftime('%Y-%m-%d') if ts else None


def commands_report(paths, days=DEFAULT_DAYS, transcripts=True, now=None):
    """One row per served command: use, weight, references, and a status retire can act on."""
    now = now or time.time()
    since = now - days * DAY
    files = command_files(paths)
    scheduled = scheduled_prompts(paths)
    typed = defaultdict(Counter)
    sessions, projects, last = defaultdict(set), defaultdict(set), {}
    every = list(prompts(paths))
    skip_sessions = scheduled_sessions(every, scheduled)
    for prompt in every:
        if is_scheduled(prompt.text, scheduled) and (prompt.session in skip_sessions or not prompt.session):
            continue
        for name in _names(prompt.text):
            last[name] = max(last.get(name, 0), prompt.ts)
            if prompt.ts >= since:
                typed[name][prompt.harness] += 1
                sessions[name].add(prompt.session)
                if prompt.project:
                    projects[name].add(prompt.project)
    schedule_refs = Counter(name for text in scheduled for name in _names(text))
    calls = skill_calls(paths, since, skip_sessions) if transcripts else {}
    refs = references(paths, files)
    overrides = project_overrides(paths)
    added = added_dates(paths)
    grace = _iso(now - GRACE_DAYS * DAY)
    rows = []
    for name, (rel, layer) in sorted(files.items()):
        count, seen = calls.get(name, (0, 0))
        last_ts = max(last.get(name, 0), seen)
        used = sum(typed[name].values()) + count + schedule_refs[name]
        text = (_layer_root(paths, layer) / rel).read_text(errors='replace')
        since_added = added.get(rel)
        young = since_added is None or since_added > grace
        rows.append({
            'name': name, 'layer': layer, 'auto': name.startswith('auto:'),
            'lines': text.count('\n'), 'bytes': len(text.encode()),
            'typed_claude': typed[name]['claude'], 'typed_codex': typed[name]['codex'],
            'skill_calls': count, 'scheduled': schedule_refs[name],
            'sessions': len(sessions[name]), 'projects': len(projects[name]),
            'last_used': _iso(last_ts), 'added': since_added,
            'refs': refs[name], 'project_overrides': overrides[name.split(':')[-1]],
            'status': 'active' if used else ('young' if young else 'dormant'),
        })
    return rows


def _stamp(value):
    """Epoch seconds from a transcript line's ISO timestamp, or None."""
    if not isinstance(value, str):
        return None
    try:
        return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()
    except ValueError:
        return None


def token_usage(paths, since):
    """Claude token usage per session from transcripts newer than `since`, each API message counted once.

    Every content block of a reply repeats its message id and usage, and resumed or forked sessions copy lines
    into another file, so usage is deduped on message id across all files, keeping the last line seen. Lines
    carry their session's `sessionId`, so a subagent transcript (`<session>/subagents/agent-*.jsonl`) rolls up to
    the session that spawned it. Returns {session: {field: tokens, ..., 'messages': n}}.
    """
    latest = {}
    for path in (paths.claude_dir / 'projects').rglob('*.jsonl'):
        try:
            if path.stat().st_mtime < since:
                continue
            with open(path, 'rb') as handle:
                for number, line in enumerate(handle):
                    if b'"usage"' not in line:
                        continue
                    try:
                        entry = json.loads(line)
                    except ValueError:
                        continue
                    message = entry.get('message') if isinstance(entry, dict) else None
                    if not isinstance(message, dict) or not isinstance(message.get('usage'), dict):
                        continue
                    stamp = _stamp(entry.get('timestamp'))
                    if stamp is None or stamp < since:
                        continue
                    session = entry.get('sessionId') or path.stem
                    key = message.get('id')
                    latest[key if isinstance(key, str) and key else (str(path), number)] = (str(session), message['usage'])
        except OSError:
            continue
    sessions = defaultdict(Counter)
    for session, counts in latest.values():
        totals = sessions[session]
        totals['messages'] += 1
        for field in TOKEN_FIELDS:
            value = counts.get(field)
            if isinstance(value, int) and not isinstance(value, bool):
                totals[field] += value
    return sessions


def tokens_report(paths, days=TOKEN_DAYS, now=None):
    """Claude tokens over the window, split by scheduled and interactive sessions, and scheduled sessions by the
    command their opening prompt runs (a scheduled run is one command per session). Codex is not measured."""
    now = now or time.time()
    robots = scheduled_runs(prompts(paths), scheduled_prompts(paths))
    kinds = {kind: Counter(sessions=0) for kind in ('scheduled', 'interactive')}
    commands = defaultdict(Counter)
    for session, totals in token_usage(paths, now - days * DAY).items():
        rows = [kinds['interactive']]
        if session in robots:
            rows = [kinds['scheduled'], commands[run_command(robots[session])]]
        for row in rows:
            row['sessions'] += 1
            row.update(totals)
    total = Counter()
    for kind in kinds.values():
        total.update(kind)
    return {'days': days, 'since': _iso(now - days * DAY),
            'claude': {name: dict(kind) for name, kind in {**kinds, 'total': total}.items()},
            'scheduled_by_command': {name: dict(row) for name, row in
                                     sorted(commands.items(), key=lambda item: (-item[1]['output_tokens'], item[0]))},
            'codex': 'not measured'}


def render_tokens(report):
    header = f'{"claude":<13}{"sessions":>9}{"messages":>10}{"input":>13}{"output":>13}{"cache write":>14}{"cache read":>15}'
    lines = [f'Claude tokens since {report["since"]} ({report["days"]} days, each message counted once)', header]

    def line(label, row):
        return (f'{label:<13}{row.get("sessions", 0):>9,}{row.get("messages", 0):>10,}'
                + ''.join(f'{row.get(field, 0):>{width},}' for field, width in zip(TOKEN_FIELDS, (13, 13, 14, 15))))
    for kind, row in report['claude'].items():
        lines.append(line(kind, row))
    if report.get('scheduled_by_command'):
        lines.append('scheduled, by command:')
        lines.extend(line(f'  {name}'[:12], row) for name, row in report['scheduled_by_command'].items())
    lines.append(f'codex: {report["codex"]} (its history carries no token counts)')
    return lines


def _terms(text):
    words = re.findall(r"[a-z][a-z'-]+", text.lower())[:60]
    return {word[:-1] if word.endswith('s') and len(word) > 3 else word
            for word in words if word not in STOPWORDS and len(word) > 2}


def _clean(text):
    """The human's own words: no paste markers, no leading /goal, no slash command lines."""
    text = PASTE_MARKER.sub(' ', text).strip()
    if text.startswith('/goal '):
        text = text[len('/goal '):].strip()
    return '' if text.startswith(('/', '$', '!', '#', '>')) else text


def prompt_clusters(paths, days=60, min_sessions=4, limit=40, similarity=0.5, now=None):
    """Near-duplicate typed prompts, grouped across sessions, widest first.

    Greedy single pass with an inverted index: a prompt joins the cluster sharing most of its terms.
    This only proposes; judging whether a cluster is a real, uncovered workflow is the command's job.
    """
    since = (now or time.time()) - days * DAY
    scheduled = scheduled_prompts(paths)
    clusters, index = [], defaultdict(set)
    for prompt in sorted(prompts(paths), key=lambda p: p.ts):
        if prompt.ts < since or is_scheduled(prompt.text, scheduled):
            continue
        text = _clean(prompt.text)
        terms = _terms(text)
        if len(terms) < 3:
            continue
        overlap = Counter(found for term in terms for found in index[term])
        best, score = None, 0.0
        for found, shared in overlap.most_common(12):
            jaccard = shared / len(terms | clusters[found]['seed'])
            if jaccard > score:
                best, score = found, jaccard
        if best is None or score < similarity:
            best = len(clusters)
            clusters.append({'seed': terms, 'terms': Counter(), 'sessions': set(), 'projects': set(),
                             'harnesses': set(), 'first': prompt.ts, 'last': prompt.ts, 'count': 0, 'samples': []})
            for term in terms:
                index[term].add(best)
        cluster = clusters[best]
        cluster['terms'].update(terms)
        cluster['count'] += 1
        cluster['last'] = prompt.ts
        cluster['harnesses'].add(prompt.harness)
        if prompt.project:
            cluster['projects'].add(prompt.project)
        if prompt.session not in cluster['sessions'] and len(cluster['samples']) < 3:
            cluster['samples'].append(scrub(' '.join(text.split()))[:200])
        cluster['sessions'].add(prompt.session)
    rows = [{
        'sessions': len(c['sessions']), 'occurrences': c['count'], 'projects': len(c['projects']),
        'harnesses': sorted(c['harnesses']), 'first': _iso(c['first']), 'last': _iso(c['last']),
        'span_days': round((c['last'] - c['first']) / DAY),
        'terms': [term for term, _ in c['terms'].most_common(8)], 'samples': c['samples'],
    } for c in clusters if len(c['sessions']) >= min_sessions]
    rows.sort(key=lambda row: (-row['sessions'], -row['projects'], -row['occurrences']))
    return rows[:limit]


def render_commands(rows):
    lines = [f'{"command":<26}{"status":<9}{"typed":>6}{"model":>6}{"sched":>6}{"sess":>6}{"refs":>5}{"lines":>7}  last used']
    for row in sorted(rows, key=lambda r: (r['status'] != 'dormant', r['typed_claude'] + r['typed_codex'], r['name'])):
        typed = row['typed_claude'] + row['typed_codex']
        lines.append(f'{row["name"]:<26}{row["status"]:<9}{typed:>6}{row["skill_calls"]:>6}{row["scheduled"]:>6}'
                     f'{row["sessions"]:>6}{len(row["refs"]):>5}{row["lines"]:>7}  {row["last_used"] or "never"}')
    return lines


def render_clusters(rows):
    lines = []
    for row in rows:
        lines.append(f'{row["sessions"]} sessions · {row["projects"]} projects · {row["span_days"]} days · '
                     f'{"+".join(row["harnesses"])} · last {row["last"]} — {" ".join(row["terms"][:6])}')
        lines.extend(f'    "{sample[:120]}"' for sample in row['samples'][:2])
    return lines or ['no prompt repeats across enough sessions']

