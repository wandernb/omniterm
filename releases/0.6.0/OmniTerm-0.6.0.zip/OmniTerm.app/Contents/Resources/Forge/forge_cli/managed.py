"""Global config edits forge keeps healthy: the AGENTS.md block and the SessionStart/Stop hooks.

`forge agents-md --apply` / `forge hooks --apply` record what they manage in install.json; doctor checks
those records and `doctor --repair` (run by the LaunchAgent) restores them. `--remove --apply` drops the
record, so a deliberately removed block or hook is never re-added.
"""
from pathlib import Path

from . import agents_md, hooks


def _managed(current):
    return current.setdefault('managed', {})


def record_agents_md(current, target):
    _managed(current)['agents_md'] = str(target)


def forget_agents_md(current):
    _managed(current).pop('agents_md', None)


def record_hooks(current, harnesses, remove=False):
    recorded = set(_managed(current).get('hooks', []))
    recorded = recorded - set(harnesses) if remove else recorded | set(harnesses)
    if recorded:
        _managed(current)['hooks'] = sorted(recorded)
    else:
        _managed(current).pop('hooks', None)


def fragment(paths):
    return (paths.core_source / 'fragments' / 'AGENTS.forge.md').read_text()


def check(paths, current):
    problems = []
    managed = current.get('managed', {})
    if 'agents_md' in managed:
        target = Path(managed['agents_md'])
        changed, _ = agents_md.apply(target, fragment(paths), dry_run=True)
        if changed:
            problems.append(f'forge block missing or out of date in {target} (run `forge doctor --repair`)')
    for harness in managed.get('hooks', []):
        path, changed = hooks.install(paths, harness, dry_run=True)
        if changed:
            problems.append(f'forge SessionStart hook missing or out of date (or its Stop storage hook) in {path} (run `forge doctor --repair`)')
    return problems


def repair(paths, current):
    report = []
    managed = current.get('managed', {})
    backup_dir = paths.state_dir / 'backups'
    if 'agents_md' in managed:
        target = Path(managed['agents_md'])
        changed, _ = agents_md.apply(target, fragment(paths), backup_dir=backup_dir)
        if changed:
            report.append(f'restored forge block: {target}')
    for harness in managed.get('hooks', []):
        path, changed = hooks.install(paths, harness)
        if changed:
            report.append(f'restored forge SessionStart/Stop hooks: {path}')
    return report
