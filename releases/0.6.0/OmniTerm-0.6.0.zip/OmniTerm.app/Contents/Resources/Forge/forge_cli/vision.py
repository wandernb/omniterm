"""The mechanics under /forge:dream, /forge:vision and /forge:advance.

`blind` gives a dream a copy of the project that holds no vision and no history, so a fresh run really is
fresh. `save` commits the one vision file and nothing else. `land` is the gate that lets /forge:advance
reach the default branch unattended: plain code, so no model judges its own step, and the rule that
dreams never remove features is checked on the diff rather than promised in prose.

Land policy lives in the private `<forge>/user/vision.json`:

    {"repos": {"my-app": {"path": "~/Projects/my-app", "land": "auto",
                          "verify": ["make", "test"], "post": [["make", "smoke"]], "protected": ["db/*"]}}}

A repo that is missing, not `auto`, or not `internal` in the exposure map never lands: its steps stay on
branches. `verify` runs inside the step's worktree; `post` runs in the live checkout after the merge, and a
failure there reverts the step.
"""
from datetime import date
import fnmatch
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shutil
import subprocess
import tempfile

from . import exposure

VISION = 'knowledge/VISION.md'
BRANCH_PREFIX = 'forge/advance/'
MAX_CHANGED_LINES = 300
MAX_BLIND_BYTES = 200 * 1024 * 1024
MAX_FILE_BYTES = 1024 * 1024
TIMEOUT = 1800
UNRUNNABLE = 'could not run:'  # proves nothing, so it can never match an equally broken base

# Outward first: a product grows by beating its market, so four of six lenses face customers, rivals and revenue.
LENSES = {
    'market and competitors': ['competitor teardown', 'feature-parity matrix against the closest rivals',
                               'Product Hunt and open-source scan', 'Blue Ocean', 'Wardley map'],
    'growth and revenue': ['pricing and packaging', 'AARRR funnel', 'expansion revenue', 'unit economics',
                           'working backwards press release'],
    'product': ['12-month ideal state', '10x for 2x effort', 'opportunity solution tree', 'jobs-to-be-done'],
    'usability': ['friction log of the first hour', 'journey map', 'SCAMPER', 'jobs-to-be-done'],
    'scale and platform': ['100x load thought experiment', 'Theory of Constraints', 'platform and ecosystem play',
                           'TRIZ contradictions', 'first principles'],
    'operations and reliability': ['pre-mortem', 'service blueprint', 'cost-to-serve', 'inversion'],
}
PERSONAS = (
    'a first-week user', 'a daily power user', 'a buyer comparing three vendors', 'a churned customer',
    'a user migrating from a rival tool', 'a head of growth', 'a pricing lead', 'a competitor product manager',
    'an investor doing diligence', 'a partner building on top of it', 'a team lead rolling it out to fifty people',
    'a finance lead', 'an administrator', 'an on-call engineer',
)
NEVER_COPIED = re.compile(r'(^|/)(\.env[^/]*|secrets\.yml|secrets|\.git)(/|$)|^config/secrets/')
# What a step may never change: the rules that bind it, and the gate that checks it.
ALWAYS_PROTECTED = (
    'forge_cli/vision.py', 'tests/test_vision.py', 'forge_cli/exposure.py', 'forge_cli/routines.py', 'forge_cli/attic.py',
    'forge_cli/auto.py',
    'core/knowledge/forge-momentum.md', 'core/knowledge/forge-dreaming.md', 'core/knowledge/forge-self-tending.md',
    'core/knowledge/forge-routines.md', 'core/commands/dream.md', 'core/commands/vision.md', 'core/commands/advance.md',
    VISION, '.github/*', '*.lock',
)
ITEM = re.compile(r'^### (V-\d+)\s*[—-]\s*(.+)$', re.M)
FIELD = re.compile(r'\*\*(Horizon|Status|Seen|Lens|Impact|Bet|Next step):\*\*\s*([^·\n]+)')
HORIZONS = {'now': 0, 'next': 1, 'far': 2}
IMPACTS = {'high': 0, 'medium': 1, 'low': 2}  # unrated items count as medium


def _git(root, *args, check=True, env=None):
    done = subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True, timeout=120, check=False,
                          env=env)
    if check and done.returncode:
        raise ValueError(f'git {" ".join(args)}: {done.stderr.strip() or done.stdout.strip()}')
    return done.stdout.rstrip()  # porcelain output starts with a meaningful space


def repo_root(start=None):
    return Path(_git(start or os.getcwd(), 'rev-parse', '--show-toplevel'))


def repo_name(root):
    """`@head` checkouts are named after their parent, matching the routine ledgers."""
    root = Path(root)
    return root.parent.name if root.name.startswith('@') else root.name


def state_dir(paths, name):
    return paths.state_dir / 'vision' / name


def briefing(name, today=None):
    """The day's lens brief: varied by date and repo alone, so variety needs no memory of past runs."""
    today = today or date.today().isoformat()
    rng = random.Random(hashlib.sha256(f'{name}:{today}'.encode()).hexdigest())
    personas = rng.sample(PERSONAS, len(LENSES))
    return [{'lens': lens, 'method': rng.choice(methods), 'persona': persona}
            for (lens, methods), persona in zip(LENSES.items(), personas)]


def _copyable(root):
    listed = _git(root, 'ls-files', '-co', '--exclude-standard', '-z')
    for rel in sorted(set(filter(None, listed.split('\0')))):
        path = root / rel
        if rel == VISION or NEVER_COPIED.search(rel) or path.is_symlink() or not path.is_file():
            continue
        yield rel, path


def blind(paths, start=None, today=None, base=None):
    """Copy the working tree, minus the vision, secrets and all history, for one blind dream."""
    root = repo_root(start)
    name = repo_name(root)
    today = today or date.today().isoformat()
    tree = Path(tempfile.mkdtemp(prefix=f'forge-dream-{name}-', dir=base))
    total = 0
    try:
        for rel, path in _copyable(root):
            size = path.stat().st_size
            if size > MAX_FILE_BYTES:
                continue
            total += size
            if total > MAX_BLIND_BYTES:
                raise ValueError(f'{name} is over {MAX_BLIND_BYTES >> 20} MB of text; dream on a narrower checkout')
            target = tree / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    except (OSError, ValueError):
        shutil.rmtree(tree, ignore_errors=True)
        raise
    return {'repo': name, 'date': today, 'tree': str(tree), 'bytes': total,
            'dream': str(state_dir(paths, name) / 'dreams' / f'{today}.md'), 'lenses': briefing(name, today)}


def clean(tree):
    """Remove a blind copy. Only ever a directory `blind` made."""
    path = Path(tree)
    if not path.name.startswith('forge-dream-'):
        raise ValueError(f'not a blind copy: {tree}')
    shutil.rmtree(path, ignore_errors=True)


def pending_dreams(paths, name):
    return sorted(str(path) for path in (state_dir(paths, name) / 'dreams').glob('*.md'))


def retire_dream(paths, name, dream, keep=14):
    """Move a reconciled dream aside and keep the last few, so reconciling is never repeated."""
    source = Path(dream)
    if source.parent != state_dir(paths, name) / 'dreams':
        raise ValueError(f'not a dream of {name}: {dream}')
    done = state_dir(paths, name) / 'reconciled'
    done.mkdir(parents=True, exist_ok=True)
    os.replace(source, done / source.name)
    for old in sorted(done.glob('*.md'))[:-keep]:
        old.unlink()
    return str(done / source.name)


def items(text):
    """Parse the vision into rows. Unknown or missing fields stay empty rather than failing."""
    marks = list(ITEM.finditer(text))
    rows = []
    for index, mark in enumerate(marks):
        end = marks[index + 1].start() if index + 1 < len(marks) else len(text)
        fields = dict(FIELD.findall(text[mark.end():end]))
        seen = re.search(r'\d+', fields.get('Seen', ''))
        impact = re.match(r'\w+', fields.get('Impact', '').strip().lower())  # "high — revenue" rates as high
        rows.append({'id': mark.group(1), 'title': mark.group(2).strip(),
                     'horizon': fields.get('Horizon', '').strip().lower(),
                     'status': fields.get('Status', '').strip().lower(),
                     'lens': fields.get('Lens', '').strip(), 'seen': int(seen.group()) if seen else 1,
                     'impact': impact.group() if impact else '', 'bet': fields.get('Bet', '').strip(),
                     'next_step': fields.get('Next step', '').strip()})
    return rows


def queue(rows):
    """Work in order: finish what started, then the nearest horizon, then the biggest impact, then what dreams keep finding."""
    live = [row for row in rows if row['status'] in ('open', 'in-progress')]
    return sorted(live, key=lambda r: (r['status'] != 'in-progress', HORIZONS.get(r['horizon'], 3),
                                       IMPACTS.get(r.get('impact', ''), 1),
                                       -r['seen'], r['id']))


def status(start=None):
    root = repo_root(start)
    path = root / VISION
    rows = items(path.read_text()) if path.is_file() else []
    return {'repo': repo_name(root), 'vision': str(path), 'exists': path.is_file(), 'items': len(rows),
            'queue': queue(rows)}


def _identity(root):
    """The last commit's author, because scheduled sessions may have no git identity."""
    name, email = _git(root, 'log', '-1', '--format=%an%n%ae').splitlines()
    return ['-c', f'user.name={name}', '-c', f'user.email={email}']


def save(start, message, dry_run=False):
    """Commit the vision file alone, leaving everything else staged or dirty exactly as it was."""
    root = repo_root(start)
    if not (root / VISION).is_file():
        raise ValueError(f'no {VISION} in {root}')
    if not _git(root, 'status', '--porcelain', '--', VISION):
        return 'vision unchanged'
    if dry_run:
        return f'would commit {VISION}'
    _git(root, 'add', '--', VISION)
    _git(root, *_identity(root), 'commit', '--only', '-q', '-m', message, '--', VISION)
    return f'committed {VISION} as {_git(root, "rev-parse", "--short", "HEAD")}'


def load_policy(paths, name):
    try:
        repos = json.loads((paths.user / 'vision.json').read_text())['repos']
    except (OSError, ValueError, KeyError, TypeError):
        return None
    entry = repos.get(name)
    return entry if isinstance(entry, dict) else None


def diff_refusals(root, base, branch, extra_protected=()):
    """Everything in the step's diff that forbids landing. Empty means the shape is acceptable."""
    span = f'{base}...{branch}'
    found = []
    for line in _git(root, 'diff', '--name-status', '-M', span).splitlines():
        status_code, *names = line.split('\t')
        if status_code.startswith('D'):
            found.append(f'removes {names[0]}: a step adds or improves, it never removes')
        elif status_code.startswith('R'):
            found.append(f'renames {names[0]}: a served name must keep working')
        if any('.attic/' in name for name in names):
            found.append(f'touches the attic: {names[-1]}')
        for pattern in (*ALWAYS_PROTECTED, *extra_protected):
            for name in names:
                if fnmatch.fnmatch(name, pattern):
                    found.append(f'protected path: {name}')
    added = deleted = 0
    for line in _git(root, 'diff', '--numstat', span).splitlines():
        plus, minus, _ = line.split('\t', 2)
        added += int(plus) if plus.isdigit() else 0
        deleted += int(minus) if minus.isdigit() else 0
    if added + deleted > MAX_CHANGED_LINES:
        found.append(f'{added + deleted} changed lines, a step is at most {MAX_CHANGED_LINES}')
    if not added and not deleted:
        found.append('empty diff')
    if deleted > max(40, added):
        found.append(f'deletes {deleted} lines against {added} added: looks like removal, not improvement')
    return found


def _dirty(root):
    """Paths with uncommitted work in the live checkout, untracked included."""
    listed = _git(root, 'status', '--porcelain', '-z', '--untracked-files=all')
    return {entry[3:] for entry in listed.split('\0') if len(entry) > 3}


def _run(command, cwd):
    """(exit code, FAILED/ERROR lines). A missing tool or a timeout is a failure, never a pass."""
    try:
        done = subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=TIMEOUT, check=False)
    except (OSError, subprocess.SubprocessError) as error:
        return 1, {f'{UNRUNNABLE} {error}'}
    lines = (done.stdout + done.stderr).splitlines()
    failures = {line.split(' - ')[0].strip() for line in lines if line.startswith(('FAILED', 'ERROR'))}
    return done.returncode, failures


def verify(root, base, worktree, command):
    """None when the step is green or adds no failure to an already red base; otherwise why not."""
    code, failures = _run(command, worktree)
    if code == 0:
        return None
    if not failures or any(line.startswith(UNRUNNABLE) for line in failures):
        return f'verify exited {code} with no attributable failures: {", ".join(sorted(failures)) or "no detail"}'
    holder = Path(tempfile.mkdtemp(prefix='forge-land-base-'))
    checkout = holder / 'base'
    try:
        _git(root, 'worktree', 'add', '-q', '--detach', str(checkout), base)
        _, known = _run(command, checkout)
    finally:
        _git(root, 'worktree', 'remove', '--force', str(checkout), check=False)
        shutil.rmtree(holder, ignore_errors=True)
    new = failures - known
    return f'new failures: {", ".join(sorted(new))}' if new else None


def land(paths, branch, worktree, start=None, dry_run=False):
    """Fast-forward one proven step onto the default branch, or say exactly why not."""
    root = repo_root(start)
    name = repo_name(root)
    policy = load_policy(paths, name)
    if not policy or policy.get('land') != 'auto':
        raise ValueError(f'{name} is not `land: auto` in vision.json; the step stays on {branch}')
    tier, _, listed = exposure.lookup(paths, root)
    if not listed or tier != 'internal':
        raise ValueError(f'{name} is {tier}: only internal projects land unattended')
    if not branch.startswith(BRANCH_PREFIX):
        raise ValueError(f'{branch} is not a {BRANCH_PREFIX} branch')
    default = _git(root, 'rev-parse', '--abbrev-ref', 'HEAD')
    head = _git(root, 'rev-parse', 'HEAD')
    if _git(root, 'merge-base', head, branch) != head:
        raise ValueError(f'{branch} is not based on {default} at {head[:8]}: rebuild it on the current head')
    refusals = diff_refusals(root, head, branch, policy.get('protected', ()))
    touched = set(_git(root, 'diff', '--name-only', f'{head}...{branch}').splitlines())
    refusals += [f'uncommitted work in the live checkout: {name_}' for name_ in sorted(touched & _dirty(root))]
    if refusals:
        raise ValueError('refused: ' + '; '.join(dict.fromkeys(refusals)))
    if _git(root, '-C', str(worktree), 'rev-parse', 'HEAD') != _git(root, 'rev-parse', branch):
        raise ValueError(f'{worktree} is not at the tip of {branch}')
    if not policy.get('verify'):
        raise ValueError(f'{name} declares no verify command: nothing could prove this step')
    failure = verify(root, head, worktree, policy['verify'])
    if failure:
        raise ValueError(f'refused: {failure}')
    if dry_run:
        return {'landed': False, 'branch': branch, 'would_land_on': default}
    _git(root, 'merge', '--ff-only', '-q', branch)
    tip = _git(root, 'rev-parse', 'HEAD')
    for command in policy.get('post', ()):
        code, _ = _run(command, root)
        if code:
            _git(root, *_identity(root), 'revert', '--no-edit', f'{head}..{tip}')
            for again in policy.get('post', ()):
                _run(again, root)
            raise ValueError(f'post check {" ".join(command)} failed; reverted, {default} is back at the old tree')
    return {'landed': True, 'branch': branch, 'on': default, 'commit': tip[:8]}
