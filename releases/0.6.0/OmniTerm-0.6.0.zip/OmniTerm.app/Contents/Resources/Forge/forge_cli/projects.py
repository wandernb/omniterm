"""Forge projects on this machine: find them, name them, and describe one (read-only but for the registry).

A project is the folder that holds a repository's checkouts. In the forge layout that is the container of
`@head` (with `@maintenance`, `@production` and feature worktrees beside it); a repository without that
layout is its own project. Every checkout and worktree of one repository maps to the same project, so a
session started in `acme/web/fix-billing` belongs to `acme/web`, never to `fix-billing` or `@head`.

A forge project has a `knowledge/` folder in its main checkout, or was registered. The registry,
`<forge>/state/projects.json`, holds projects added by `forge projects add` and by the SessionStart hook
for any forge project a session opens in; a bounded scan of the storage roots (`~/Projects` by default)
finds the rest. Identification reads the filesystem only (no git), so it also places paths whose worktree
has since been removed. Only `detail` runs git, each call capped by a timeout.

Machine-readable output (`--json`) carries `schema`; clients such as OmniTerm check it.
"""
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time

from . import exposure, storage

SCHEMA = 1
SKIP = frozenset(('node_modules', 'vendor', 'Vendor', 'dist', 'build', 'tmp', 'target', 'venv', 'Pods',
                  '__pycache__', 'DerivedData', 'coverage', 'log', 'logs', 'Library', 'Applications'))
SCAN_DEPTH = 4
SCAN_BUDGET = 20000  # directories visited per scan, so a huge tree cannot stall a client
GIT_TIMEOUT = 4
TEXT_LIMIT = 256 * 1024
LIST_LIMIT = 400
SECRET_NAMES = ('secrets.yml', 'secrets.yaml', 'credentials.json', 'master.key', 'id_rsa', 'id_ed25519', '.netrc')
SECRET_SUFFIXES = ('.pem', '.key', '.p12', '.keystore')
README_NAMES = ('README.md', 'README.markdown', 'README.rst', 'README.txt', 'README', 'readme.md')


def registry_path(paths):
    return paths.state_dir / 'projects.json'


def _real(path, paths=None):
    """Absolute and normalised, but symlinks kept: `acme/@head` may link elsewhere and must stay in acme."""
    text = str(path)
    if paths is not None and (text == '~' or text.startswith('~/')):
        text = str(paths.home) + text[1:]
    return Path(os.path.abspath(os.path.expanduser(text)))


def _is_checkout(path):
    try:
        return (path / '.git').exists()
    except OSError:
        return False


def _common_dir(checkout):
    """The repository's shared git dir for a checkout, or None when it is not a linked worktree."""
    marker = checkout / '.git'
    if not marker.is_file():
        return None
    try:
        line = marker.read_text(errors='replace').strip()
    except OSError:
        return None
    if not line.startswith('gitdir:'):
        return None
    gitdir = Path(line[len('gitdir:'):].strip())
    if not gitdir.is_absolute():
        gitdir = (checkout / gitdir).resolve()
    commondir = gitdir / 'commondir'
    if commondir.is_file():
        try:
            target = Path(commondir.read_text().strip())
            return (gitdir / target).resolve() if not target.is_absolute() else target
        except OSError:
            pass
    return gitdir.parent.parent if gitdir.parent.name == 'worktrees' else gitdir


def _layout_children(container):
    """The `@…` checkouts directly inside a folder: what makes it a forge-layout container."""
    try:
        return sorted(child for child in container.iterdir()
                      if child.name.startswith('@') and child.is_dir() and _is_checkout(child))
    except OSError:
        return []


def _main_checkout(container):
    children = _layout_children(container)
    for child in children:
        if child.name == '@head':
            return child
    for child in children:
        if (child / '.git').is_dir():
            return child
    return children[0] if children else None


def _main_for_common(common):
    """The main checkout of a repository from its shared git dir, or None for a bare store."""
    if common.name == '.git':
        return common.parent
    config = common / 'config'
    try:
        for line in config.read_text(errors='replace').splitlines():
            key, _, value = line.strip().partition('=')
            if key.strip() == 'worktree' and value.strip():
                target = Path(value.strip())
                return (common / target).resolve() if not target.is_absolute() else target
    except OSError:
        pass
    return None


def identify(path, paths=None):
    """{root, main, checkout} for any path inside a project, or None. Reads the filesystem only.

    The nearest checkout or forge-layout container wins; a plain folder with `knowledge/` (no git) is a
    project only when no repository holds the path."""
    start = _real(path, paths)
    stop = _real(paths.home) if paths is not None else Path(os.path.expanduser('~'))
    loose = None
    for folder in [start, *start.parents]:
        if folder == stop or folder == Path('/'):
            break
        if not folder.exists():
            continue
        if folder.name.startswith('@') and _is_checkout(folder):
            root = folder.parent
            return {'root': root, 'main': _main_checkout(root) or folder, 'checkout': folder}
        if _is_checkout(folder):
            if _layout_children(folder.parent):
                root = folder.parent
                return {'root': root, 'main': _main_checkout(root), 'checkout': folder}
            common = _common_dir(folder)
            if common is None:
                return {'root': folder, 'main': folder, 'checkout': folder}
            main = _main_for_common(common)
            if main is None:  # a bare store: `acme/.bare` lives in the container
                root = common.parent
                return {'root': root, 'main': _main_checkout(root) or folder, 'checkout': folder}
            if main.name.startswith('@') and _layout_children(main.parent):
                return {'root': main.parent, 'main': main, 'checkout': folder}
            return {'root': main, 'main': main, 'checkout': folder}
        if _layout_children(folder):
            return {'root': folder, 'main': _main_checkout(folder), 'checkout': None}
        if loose is None and (folder / 'knowledge').is_dir():
            loose = {'root': folder, 'main': None, 'checkout': None}
    return loose


def _forge_marker(found):
    main, root = found.get('main'), found['root']
    return any((base / 'knowledge').is_dir() for base in {main, root} if base is not None)


def load_registry(paths):
    try:
        data = json.loads(registry_path(paths).read_text())
        projects = data.get('projects', {})
        return projects if isinstance(projects, dict) else {}
    except (OSError, ValueError, AttributeError):
        return {}


@contextmanager
def _registry_lock(paths, wait=True):
    """Serialise registry writers (sessions start in parallel). Yields False when `wait` is off and it is busy."""
    paths.state_dir.mkdir(parents=True, exist_ok=True)
    with open(paths.state_dir / 'projects.lock', 'w') as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | (0 if wait else fcntl.LOCK_NB))
        except BlockingIOError:
            yield False
            return
        try:
            yield True
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def _save_registry(paths, projects):
    target = registry_path(paths)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f'.projects.{os.getpid()}.tmp')
    temporary.write_text(json.dumps({'_doc': 'Forge projects registered on this machine (forge projects).',
                                     'projects': projects}, indent=2, sort_keys=True) + '\n')
    os.replace(temporary, target)


def register(paths, path, source='manual', require_forge=False):
    """Add the project holding `path` to the registry. Returns its root, or None when there is none."""
    found = identify(path, paths)
    if found is None or (require_forge and not _forge_marker(found)):
        return None
    key = str(found['root'])
    if key in load_registry(paths):
        return found['root']
    with _registry_lock(paths, wait=source != 'session') as held:
        if not held:
            return None  # another writer has it; the next session start registers it
        projects = load_registry(paths)
        if key not in projects:
            projects[key] = {'added': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'), 'source': source}
            _save_registry(paths, projects)
    return found['root']


def unregister(paths, path):
    root = str((identify(path, paths) or {'root': _real(path, paths)})['root'])
    with _registry_lock(paths):
        projects = load_registry(paths)
        if projects.pop(root, None) is None:
            return False
        _save_registry(paths, projects)
    return True


def session_hook(paths, cwd=None):
    """SessionStart: register the forge project the session opened in. Never raises."""
    try:
        register(paths, cwd or os.getcwd(), source='session', require_forge=True)
    except Exception:  # noqa: BLE001 - a failing hook would break every session
        pass


def scan(paths, roots=None, depth=SCAN_DEPTH, budget=SCAN_BUDGET):
    """Project roots under the scan roots: {root: identify() result}. Bounded by depth and budget."""
    if roots is None:
        try:
            roots = storage.load_config(paths).get('roots') or ['~/Projects']
        except (OSError, ValueError):
            roots = ['~/Projects']
    found = {}
    visited = 0
    queue = [(_real(root, paths), 0) for root in roots]
    while queue and visited < budget:
        folder, level = queue.pop(0)
        visited += 1
        if not folder.is_dir():
            continue
        if _layout_children(folder):
            entry = identify(folder / _layout_children(folder)[0].name, paths)
            if entry is not None and entry['root'] == folder:
                found.setdefault(folder, entry)
            continue  # its children are checkouts and worktrees of the same project
        if level > 0 and _is_checkout(folder):
            entry = identify(folder, paths)
            if entry is not None:
                found.setdefault(entry['root'], entry)
            if _common_dir(folder) is not None:
                continue  # a linked worktree: its project is elsewhere and its tree is a copy
        elif level > 0 and (folder / 'knowledge').is_dir():
            entry = identify(folder, paths)
            if entry is not None:
                found.setdefault(entry['root'], entry)
        if level >= depth:
            continue
        try:
            children = sorted(child for child in folder.iterdir()
                              if child.is_dir() and not child.is_symlink()
                              and not child.name.startswith('.') and child.name not in SKIP)
        except OSError:
            continue
        queue.extend((child, level + 1) for child in children)
    return found


def _roots_for_labels(paths):
    try:
        roots = storage.load_config(paths).get('roots') or ['~/Projects']
    except (OSError, ValueError):
        roots = ['~/Projects']
    return sorted((_real(root, paths) for root in roots), key=lambda root: -len(root.parts))


def _label(root, label_roots, home):
    for base in label_roots:
        if root != base and base in root.parents:
            return str(root.relative_to(base))
    if root == home or home in root.parents:
        return '~/' + str(root.relative_to(home)) if root != home else '~'
    return str(root)


def _checkouts(root, main):
    """Checkout folders inside a container, found without git: `@…` and feature worktrees."""
    if main is None or main.parent != root:
        return [main] if main is not None else []
    result = []
    try:
        for child in sorted(root.iterdir()):
            if child.is_dir() and not child.name.startswith('.') and _is_checkout(child):
                result.append(child)
    except OSError:
        pass
    return result


def summary(paths, root, entry, label_roots, registered):
    main = entry.get('main')
    tier, guard, listed = exposure.lookup(paths, root)
    checkouts = _checkouts(root, main)
    return {
        'id': str(root), 'root': str(root), 'name': root.name, 'label': _label(root, label_roots, paths.home),
        'main': str(main) if main else None, 'forge': _forge_marker(entry),
        'layout': 'forge' if main is not None and main.parent == root and main.name.startswith('@') else 'plain',
        'checkouts': [{'name': c.name, 'path': str(c)} for c in checkouts],
        'registered': registered, 'exposure': {'tier': tier, 'guard': guard, 'listed': listed},
        'has_readme': any(((main or root) / name).is_file() for name in README_NAMES),
        'updated': _activity(checkouts or [root]),
    }


def _activity(checkouts):
    newest = 0.0
    for checkout in checkouts:
        try:
            newest = max(newest, storage.last_activity(checkout) or 0.0)
        except (OSError, ValueError, TypeError):
            pass
    return newest or None


def list_projects(paths, roots=None, include_plain=False):
    """Every forge project: registered ones plus the scan, de-duplicated by root, newest activity first."""
    found = scan(paths, roots)
    registered = set()
    for key in load_registry(paths):
        entry = identify(key, paths)
        if entry is not None:
            found.setdefault(entry['root'], entry)
            registered.add(entry['root'])
    for key in exposure.load(paths):
        if key.exists():
            entry = identify(key, paths)
            if entry is not None and entry['root'] == key:
                found.setdefault(key, entry)
    label_roots = _roots_for_labels(paths)
    projects = [summary(paths, root, entry, label_roots, root in registered) for root, entry in found.items()]
    projects = [p for p in projects if include_plain or p['forge'] or p['registered']]
    names = {}
    for project in projects:
        names.setdefault(project['name'], []).append(project)
    for same in names.values():
        for project in same:
            project['display_name'] = project['name'] if len(same) == 1 else project['label']
    projects.sort(key=lambda p: (-(p['updated'] or 0), p['label']))
    return projects


def resolve(paths, path):
    """The project for any path (a session's workspace, a worktree), or None."""
    entry = identify(path, paths)
    if entry is None:
        return None
    root = entry['root']
    result = summary(paths, root, entry, _roots_for_labels(paths), str(root) in load_registry(paths))
    result['checkout'] = str(entry['checkout']) if entry.get('checkout') else None
    result['display_name'] = result['name']
    return result


def _git(checkout, *arguments):
    environment = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0', LC_ALL='C')
    try:
        result = subprocess.run(['git', '-C', str(checkout), *arguments], capture_output=True, text=True,
                                timeout=GIT_TIMEOUT, env=environment, errors='replace')
    except (OSError, subprocess.SubprocessError):
        return None
    return result.stdout if result.returncode == 0 else None


def is_secret(relative):
    """Files a project page must never open: env files, secrets and keys (they may hold credentials)."""
    parts = Path(relative).parts
    name = parts[-1] if parts else ''
    return (name.startswith('.env') or name in SECRET_NAMES or name.endswith(SECRET_SUFFIXES)
            or any(a == 'config' and b in ('secrets', 'credentials') for a, b in zip(parts, parts[1:]))
            or '.git' in parts)


def _read_text(path):
    try:
        with open(path, 'rb') as handle:
            data = handle.read(TEXT_LIMIT + 1)
    except OSError:
        return None
    if b'\0' in data[:4096]:
        return None
    text = data[:TEXT_LIMIT].decode('utf-8', errors='replace')
    return text + ('\n…' if len(data) > TEXT_LIMIT else '')


def _listing(folder, limit=LIST_LIMIT):
    entries = []
    try:
        children = sorted(folder.iterdir(), key=lambda c: (not c.is_dir(), c.name.lower()))
    except OSError:
        return entries
    for child in children:
        if child.name in ('.git', '.DS_Store'):
            continue
        try:
            is_dir = child.is_dir()
            size = None if is_dir else child.stat().st_size
        except OSError:
            continue
        entry = {'name': child.name, 'kind': 'dir' if is_dir else 'file', 'size': size}
        if not is_dir and is_secret(child.name):
            entry['secret'] = True
        entries.append(entry)
        if len(entries) >= limit:
            break
    return entries


def _knowledge(base, limit=LIST_LIMIT):
    folder = base / 'knowledge'
    files = []
    if not folder.is_dir():
        return files
    for current, directories, names in os.walk(folder):
        directories[:] = sorted(d for d in directories if not d.startswith('.'))
        for name in sorted(names):
            if name.startswith('.'):
                continue
            path = Path(current) / name
            try:
                stat = path.stat()
            except OSError:
                continue
            files.append({'path': str(path.relative_to(base)), 'size': stat.st_size, 'modified': stat.st_mtime})
            if len(files) >= limit:
                return files
    return files


def _worktrees(main):
    text = _git(main, 'worktree', 'list', '--porcelain')
    if text is None:
        return []
    worktrees, current = [], {}
    for line in text.splitlines() + ['']:
        if not line:
            if current:
                worktrees.append(current)
            current = {}
        elif line.startswith('worktree '):
            current = {'path': line[9:], 'name': Path(line[9:]).name}
        elif line.startswith('HEAD '):
            current['head'] = line[5:]
        elif line.startswith('branch '):
            current['branch'] = line[7:].removeprefix('refs/heads/')
        elif line in ('bare', 'detached', 'locked', 'prunable') or line.startswith(('locked ', 'prunable ')):
            current[line.split(' ', 1)[0]] = True
    return [w for w in worktrees if not w.get('bare')]


def _branches(main, limit=40):
    text = _git(main, 'for-each-ref', '--sort=-committerdate', f'--count={limit}',
                '--format=%(refname:short)%00%(committerdate:unix)%00%(subject)%00%(upstream:short)%00%(upstream:track)',
                'refs/heads')
    branches = []
    for line in (text or '').splitlines():
        parts = line.split('\0')
        if len(parts) == 5:
            branches.append({'name': parts[0], 'updated': float(parts[1] or 0), 'subject': parts[2],
                             'upstream': parts[3] or None, 'track': parts[4] or None})
    return branches


def _remotes(main):
    remotes = {}
    for line in (_git(main, 'remote', '-v') or '').splitlines():
        parts = line.split()
        if len(parts) >= 2:
            remotes.setdefault(parts[0], parts[1])
    return [{'name': name, 'url': url} for name, url in remotes.items()]


def _last_commit(main):
    text = _git(main, 'log', '-1', '--format=%H%x00%s%x00%ct%x00%an')
    parts = (text or '').strip().split('\0')
    if len(parts) != 4:
        return None
    return {'sha': parts[0], 'subject': parts[1], 'time': float(parts[2] or 0), 'author': parts[3]}


def detail(paths, path):
    """Everything a project page shows: git (branches, worktrees, remotes, last commit), files, README,
    knowledge listing. Raises ValueError when `path` is in no project."""
    project = resolve(paths, path)
    if project is None:
        raise ValueError(f'no project at {path}')
    main = Path(project['main']) if project['main'] else Path(project['root'])
    git = None
    if _is_checkout(main):
        status = _git(main, 'status', '--porcelain=v1', '--untracked-files=normal')
        git = {
            'branch': (_git(main, 'branch', '--show-current') or '').strip() or None,
            'last_commit': _last_commit(main), 'remotes': _remotes(main), 'branches': _branches(main),
            'worktrees': _worktrees(main),
            'changes': None if status is None else len([line for line in status.splitlines() if line.strip()]),
        }
    readme = next((main / name for name in README_NAMES if (main / name).is_file()), None)
    project.update({
        'git': git, 'files': _listing(main),
        'readme': {'path': readme.name, 'text': _read_text(readme)} if readme else None,
        'knowledge': _knowledge(main),
    })
    return project


def read_file(paths, path, relative):
    """One text file of a project's main checkout, confined to it and capped. Raises ValueError."""
    project = resolve(paths, path)
    if project is None:
        raise ValueError(f'no project at {path}')
    base = Path(project['main'] or project['root']).resolve()
    target = (base / relative).resolve()
    if target != base and base not in target.parents:
        raise ValueError('path leaves the project')
    if is_secret(str(target.relative_to(base))):
        raise ValueError(f'{relative} may hold secrets and is not shown')
    if not target.is_file():
        raise ValueError(f'no file {relative}')
    text = _read_text(target)
    if text is None:
        raise ValueError(f'{relative} is not text')
    return {'path': str(target.relative_to(base)), 'text': text}


def list_folder(paths, path, relative=''):
    """One folder of a project's main checkout, confined to it: the Files tab's browser."""
    project = resolve(paths, path)
    if project is None:
        raise ValueError(f'no project at {path}')
    base = Path(project['main'] or project['root']).resolve()
    target = (base / (relative or '.')).resolve()
    if target != base and base not in target.parents:
        raise ValueError('path leaves the project')
    if not target.is_dir():
        raise ValueError(f'no folder {relative}')
    shown = '' if target == base else str(target.relative_to(base))
    return {'path': shown, 'entries': _listing(target)}


def human(projects):
    lines = []
    for project in projects:
        mark = '◆' if project['forge'] else '·'
        checkouts = len(project['checkouts'])
        extra = f'  ({checkouts} checkouts)' if checkouts > 1 else ''
        lines.append(f'{mark} {project["label"]:<40} {project["root"]}{extra}')
    return lines or ['no forge projects found']


def run(args, paths):
    action = args.action or 'list'
    started = time.monotonic()
    if action == 'list':
        result = list_projects(paths, include_plain=args.all)
        payload = {'schema': SCHEMA, 'projects': result, 'elapsed': round(time.monotonic() - started, 3)}
        print(json.dumps(payload) if args.json else '\n'.join(human(result)))
        return 0
    if action == 'resolve' and args.stdin:
        import sys
        resolved = {}
        for line in sys.stdin.read().splitlines()[:2000]:
            if line.strip():
                try:
                    entry = identify(line.strip(), paths)
                except (OSError, ValueError):
                    entry = None
                resolved[line.strip()] = str(entry['root']) if entry else None
        print(json.dumps({'schema': SCHEMA, 'resolved': resolved}))
        return 0
    target = args.path or os.getcwd()
    if action == 'resolve':
        payload = {'schema': SCHEMA, 'project': resolve(paths, target)}
        if args.json:
            print(json.dumps(payload))
        else:
            print(payload['project']['root'] if payload['project'] else 'no project')
        return 0 if payload['project'] else 1
    if action == 'show':
        payload = {'schema': SCHEMA, 'project': detail(paths, target)}
        print(json.dumps(payload) if args.json else json.dumps(payload, indent=2))
        return 0
    if action == 'file':
        if not args.file:
            raise ValueError('forge projects file <project path> <relative file>')
        payload = {'schema': SCHEMA, 'file': read_file(paths, target, args.file)}
        print(json.dumps(payload) if args.json else payload['file']['text'])
        return 0
    if action == 'files':
        payload = {'schema': SCHEMA, 'folder': list_folder(paths, target, args.file or '')}
        print(json.dumps(payload) if args.json else '\n'.join(e['name'] for e in payload['folder']['entries']))
        return 0
    if action == 'add':
        root = register(paths, target)
        if root is None:
            raise ValueError(f'no project at {target}')
        print(f'registered {root}')
        return 0
    if action == 'remove':
        print('removed' if unregister(paths, target) else 'not registered')
        return 0
    raise ValueError(f'unknown action {action}')
