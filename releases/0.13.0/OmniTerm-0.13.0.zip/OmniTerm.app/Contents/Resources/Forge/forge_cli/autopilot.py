"""Drive /forge:autopilot from outside any session: one fresh harness process per tick.

Every tick reads and writes its own ledger (`~/.forge/state/autopilot/<repo>.md`), so a tick needs no
memory of the last one. That makes a tick a single non-interactive run — `codex exec` or `claude -p` —
and lets Codex, which has no in-session scheduler, loop forever without its context growing.

Ticks run one after another, never overlapping. The delay between them is the fixed interval, or the
self-paced delay the tick wrote to `<repo>.next`.
"""
from contextlib import nullcontext
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

from . import vision

HARNESSES = ('codex', 'claude')
DEFAULT_DELAY = 300
MIN_DELAY, MAX_DELAY = 60, 3600
TICK_TIMEOUT = 2 * 3600
LOG_CAP = 5 * 1024 * 1024
RUNNER_ENV = 'FORGE_AUTOPILOT_RUNNER'
OUTPUT_TAIL = 4000  # characters of a Claude tick's output the log keeps when it has no result text
TOKEN_FIELDS = ('input_tokens', 'output_tokens', 'cache_read_input_tokens', 'cache_creation_input_tokens')


def state_dir(paths):
    return paths.state_dir / 'autopilot'


def files(paths, name):
    base = state_dir(paths)
    return {kind: base / f'{name}{suffix}' for kind, suffix in (
        ('ledger', '.md'), ('hold', '.hold'), ('next', '.next'), ('pid', '.runner.json'), ('log', '.log'),
        ('receipts', '.receipts.jsonl'), ('tick', '.tick.json'))}


def parse_interval(text):
    """`20m` / `1h` / `90s` / `300` → seconds; empty or `auto` → None (self-paced)."""
    if not text or text == 'auto':
        return None
    match = re.fullmatch(r'(\d+)\s*([smh]?)', text.strip().lower())
    if not match:
        raise ValueError(f'interval must look like 20m, 1h or 300s, not {text!r}')
    seconds = int(match.group(1)) * {'': 1, 's': 1, 'm': 60, 'h': 3600}[match.group(2)]
    if seconds < MIN_DELAY:
        raise ValueError(f'interval must be at least {MIN_DELAY}s')
    return seconds


def tick_prompt(harness, focus=None):
    # The runner is detached by design: nobody watches its ticks, so they take the unattended branch model.
    head = '$forge-autopilot' if harness == 'codex' else '/forge:autopilot'
    return ' '.join(part for part in (head, '--tick', '--unattended', focus) if part)


def git_common_dir(root, run=subprocess.run):
    """A linked worktree (@maintenance) keeps its refs, index and FETCH_HEAD in the main checkout's .git, outside
    the worktree; None when that directory already lies inside root."""
    try:
        done = run(['git', '-C', str(root), 'rev-parse', '--path-format=absolute', '--git-common-dir'],
                   capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError):
        return None
    common = Path(done.stdout.strip()) if done.returncode == 0 and done.stdout.strip() else None
    if common is None or common.is_relative_to(Path(root).resolve()):
        return None
    return common


def tick_command(paths, harness, root, focus=None, run=subprocess.run):
    """The argv of one tick. Both harnesses get write access to forge's state dir (ledgers, locks), which lies
    outside the repo, and to a linked worktree's git dir, without which an unattended tick cannot fetch,
    commit or push; Codex also gets network for `gh` and package installs."""
    prompt = tick_prompt(harness, focus)
    writable = [str(paths.state_dir)]  # all of ~/.forge/state: autopilot ledgers and the maintenance worktree lock
    common = git_common_dir(root, run)
    if common:
        writable.append(str(common))
    dirs = [arg for path in writable for arg in ('--add-dir', path)]
    if harness == 'codex':
        # --approve-for-me implies the workspace-write sandbox; codex refuses it next to --sandbox.
        return ['codex', 'exec', '--cd', str(root), '--approve-for-me', *dirs, '-c', 'sandbox_workspace_write.network_access=true', prompt]
    if harness == 'claude':
        # JSON output carries the tick's token usage, which run_tick writes to its receipt.
        return ['claude', '-p', prompt, '--output-format', 'json', '--permission-mode', 'auto', *dirs]
    raise ValueError(f'harness must be one of {", ".join(HARNESSES)}')


def next_delay(paths, name, interval):
    """Fixed interval wins; otherwise the tick's own choice, clamped; otherwise the default."""
    if interval:
        return interval
    try:
        chosen = int(files(paths, name)['next'].read_text().strip())
    except (OSError, ValueError):
        return DEFAULT_DELAY
    return max(MIN_DELAY, min(MAX_DELAY, chosen))


def alive(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def runner(paths, name):
    """The live runner's record, or None (a record whose process is gone counts as none)."""
    try:
        record = json.loads(files(paths, name)['pid'].read_text())
    except (OSError, ValueError):
        return None
    return record if alive(int(record.get('pid', 0))) else None


def _log(paths, name, line):
    path = files(paths, name)['log']
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.stat().st_size > LOG_CAP:
        os.replace(path, path.with_suffix('.log.1'))
    stamp = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    with path.open('a') as handle:
        handle.write(f'[{stamp}] {line}\n')
    return path


def _claim(paths, name, record):
    current = runner(paths, name)
    if current and current['pid'] != os.getpid():
        raise ValueError(f"an autopilot runner for {name} is already running (pid {current['pid']}); "
                         f'stop it with: forge autopilot stop')
    path = files(paths, name)['pid']
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(record))
    os.replace(temp, path)


def _release(paths, name):
    path = files(paths, name)['pid']
    try:
        if json.loads(path.read_text()).get('pid') == os.getpid():
            path.unlink()
    except (OSError, ValueError):
        pass


def tick_result(output):
    """The `{"type": "result"}` object of a `claude -p --output-format json` run, or None. Claude prints it bare,
    or, when the `verbose` setting is on, as the last element of a JSON array of the whole transcript."""
    candidates = [output, *reversed(output.splitlines())]
    for text in candidates:
        try:
            parsed = json.loads(text)
        except ValueError:
            continue
        for item in reversed(parsed if isinstance(parsed, list) else [parsed]):
            if isinstance(item, dict) and item.get('type') == 'result':
                return item
    return None


def tick_usage(result):
    """Tokens, cost, turns and session from a tick's result; every field None without one (a Codex tick, a
    timeout, a crash)."""
    result = result or {}
    usage = result.get('usage') if isinstance(result.get('usage'), dict) else {}
    return {**{key: usage.get(key) for key in TOKEN_FIELDS}, 'cost_usd': result.get('total_cost_usd'),
            'turns': result.get('num_turns'), 'session': result.get('session_id')}


def _result_text(result):
    """What the log keeps of a result: its text, or for an error result (no `result` field) its subtype and errors."""
    if isinstance(result.get('result'), str):
        return result['result']
    return f"{result.get('subtype', 'result')}: {json.dumps(result.get('errors'))[:OUTPUT_TAIL]}"


def _receipt(paths, name, record):
    with files(paths, name)['receipts'].open('a') as handle:
        handle.write(json.dumps(record) + '\n')


def _head(root):
    """`git rev-parse HEAD` in `root`, or None when it fails or `root` is not a git checkout: the join key
    between a tick's receipt and the commit it made."""
    try:
        done = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=str(root), capture_output=True, text=True,
                              timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    return (done.stdout.strip() or None) if done.returncode == 0 else None


def run_tick(paths, name, command, root, popen=subprocess.Popen, timeout=TICK_TIMEOUT):
    """One tick, output appended to the capped log and one receipt line (tick id, wall-clock, exit code, HEAD before
    and after, and, for Claude, tokens) appended to `<repo>.receipts.jsonl`. Returns the exit code (None on timeout).

    Claude's JSON goes to `<repo>.tick.json`, overwritten each tick, so a verbose transcript never floods the
    log; the log gets its result text, an error result's subtype and errors, or the output's tail when there is no
    result."""
    log = _log(paths, name, 'tick: ' + ' '.join(command))
    started, clock = datetime.now(timezone.utc), time.monotonic()
    head_before = _head(root)
    claude = Path(command[0]).name == 'claude'
    capture = files(paths, name)['tick']
    env = dict(os.environ, **{RUNNER_ENV: '1'})
    with log.open('a') as handle, (capture.open('w') if claude else nullcontext(handle)) as out:
        process = popen(command, cwd=str(root), stdout=out, stderr=handle if claude else subprocess.STDOUT,
                        stdin=subprocess.DEVNULL, env=env)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.terminate()
            process.wait()
            code = None
        except BaseException:
            process.terminate()
            process.wait()
            raise
    result = None
    if claude:
        try:
            output = capture.read_text(errors='replace')
        except OSError:
            output = ''
        result = tick_result(output)
        text = _result_text(result) if result else output[-OUTPUT_TAIL:]
        if text.strip():
            # `replace`: a `\ud800` escape in Claude's JSON decodes to a lone surrogate UTF-8 cannot encode.
            with log.open('a', errors='replace') as handle:
                handle.write(text.rstrip('\n') + '\n')
    _receipt(paths, name, {'tick': started.strftime('%Y%m%dT%H%M%SZ'), 'started': started.isoformat(),
                           'harness': Path(command[0]).name, 'wall_s': round(time.monotonic() - clock, 1),
                           'exit': code if code is not None else 'timeout', 'head_before': head_before,
                           'head_after': _head(root), **tick_usage(result)})
    _log(paths, name, f'tick exit: {code if code is not None else "timeout"}')
    return code


def run(paths, root, harness, interval=None, focus=None, once=False, dry_run=False,
        popen=subprocess.Popen, sleep=time.sleep, timeout=TICK_TIMEOUT):
    """The loop. Never ends on its own: only `stop`, a signal, or `once`."""
    root = Path(root)
    name = vision.repo_name(root)
    command = tick_command(paths, harness, root, focus)
    if dry_run:
        return {'repo': name, 'command': command, 'interval': interval or 'self-paced',
                'state': str(state_dir(paths))}
    if shutil.which(command[0]) is None and popen is subprocess.Popen:
        raise ValueError(f'{command[0]} is not on PATH')
    _claim(paths, name, {'pid': os.getpid(), 'harness': harness, 'root': str(root), 'focus': focus,
                         'interval': interval, 'started': datetime.now(timezone.utc).isoformat()})
    previous = signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    ticks, last_exit = 0, None
    try:
        while True:
            if files(paths, name)['hold'].exists():
                _log(paths, name, 'held: no tick')
            else:
                last_exit = run_tick(paths, name, command, root, popen, timeout)
                ticks += 1
            if once:
                break
            sleep(next_delay(paths, name, interval))
    finally:
        signal.signal(signal.SIGTERM, previous)
        _release(paths, name)
    return {'repo': name, 'ticks': ticks, 'last_exit': last_exit}


def start(paths, root, harness, interval=None, focus=None, forge_bin=None):
    """Detach `forge autopilot run` into its own session, so it outlives the shell that started it."""
    root = Path(root)
    name = vision.repo_name(root)
    current = runner(paths, name)
    if current:
        return {'repo': name, 'already_running': current}
    argv = [sys.executable, str(forge_bin or paths.repo / 'bin' / 'forge'), 'autopilot', 'run',
            '--harness', harness, '--repo', str(root)]
    if interval:
        argv += ['--interval', f'{interval}s']
    if focus:
        argv += ['--focus', focus]
    log = _log(paths, name, 'start: ' + ' '.join(argv))
    with log.open('a') as handle:
        process = subprocess.Popen(argv, stdout=handle, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                   start_new_session=True)
    return {'repo': name, 'pid': process.pid, 'log': str(log)}


def stop(paths, name):
    current = runner(paths, name)
    if not current:
        return {'repo': name, 'stopped': False, 'reason': 'no runner'}
    os.kill(current['pid'], signal.SIGTERM)
    return {'repo': name, 'stopped': True, 'pid': current['pid']}


def status(paths, name):
    found = files(paths, name)
    return {'repo': name, 'runner': runner(paths, name), 'held': found['hold'].exists(),
            'next_delay': next_delay(paths, name, None) if found['next'].exists() else None,
            'ledger': str(found['ledger']) if found['ledger'].exists() else None, 'log': str(found['log'])}
